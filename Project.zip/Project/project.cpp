#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include <iostream>
#include <gl/glew.h>				//--- �ʿ��� ������� include
#include <gl/freeglut.h>
#include <gl/freeglut_ext.h> 
#include <ctime>
#include <fstream>
#include <gl/glm/glm.hpp>
#include <gl/glm/ext.hpp>
#include <gl/glm/gtc/matrix_transform.hpp>
#include <cmath>
#include <sstream>
#include <vector>
#include <string>
#include <cstdlib>
#include <algorithm>

#define MAX 1000
#define Pie 3.1415926

const int windowWidth = 1200;
const int windowHeight = 900;

void Keyboard(unsigned char key, int x, int y);
void Keyboard_up(unsigned char key, int x, int y);
void TimerFunction(int value);
//void Mouse(int button, int state, int x, int y);
void Motion(int x, int y);
void SpecialKeyboard(int key, int x, int y);

char* filetobuf(const char* file);
void make_vertexShaders();
void make_fragmentShaders();

glm::vec3 generateRandomDirection();
GLuint make_shaderProgram();
GLvoid drawScene(GLvoid);
GLvoid Reshape(int w, int h);

GLint width, height;
GLchar* vertexSource, * fragmentSource; // �ҽ��ڵ� ���� ����
GLuint shaderProgramID;  // ���̴� ���α׷� �̸�
GLuint shaderBackground;
GLuint vertexShader;  // ���ؽ� ���̴� ��ü
GLuint fragmentShader; // �����׸�Ʈ ���̴� ��ü
void InitBuffer();
void InitTexture();
glm::vec2 calculate_tex_coord(const glm::vec3& position);

struct Vertex {
	glm::vec3 position;
	glm::vec3 normal = glm::vec3(0.0f);
	glm::vec2 texCoord = glm::vec2(0.0f);
};

struct Face {
	unsigned int v1, v2, v3;  // ���� �ε���
};

struct FaceIndex {
	unsigned int vertexIndex;
	unsigned int texCoordIndex;
};

struct Model {
	GLuint vbo[1];                      // Vertex�� VBO
	GLuint vao;                         // Vertex Array Object
	GLuint ebo;                         // Element Buffer Object
	std::vector<Vertex> vertices;       // ���� ������
	std::vector<Face> faces;            // �� ������
	std::vector<unsigned int> indices;  // �ﰢ�� �ε��� ������
};

void read_obj_file(const std::string& filename, Model& model, int normalDirection);
void InitBuffer_obj(Model& model);

void read_obj_file(const std::string& filename, Model& model, int normalDirection) {
	std::ifstream file(filename);
	if (!file) {
		std::cerr << "Error opening file: " << filename << std::endl;
		std::exit(EXIT_FAILURE);
	}

	std::string line;
	model.vertices.clear();
	model.faces.clear();
	std::vector<glm::vec2> tempTexCoords; // �ؼ� ��ǥ �����

	while (std::getline(file, line)) {
		if (line.empty() || line[0] == '#') continue;

		if (line[0] == 'v' && line[1] == ' ') {
			Vertex vertex;
			std::istringstream iss(line.substr(2));
			iss >> vertex.position.x >> vertex.position.y >> vertex.position.z;
			model.vertices.push_back(vertex);
		}
		else if (line[0] == 'vt') { // �ؼ� ��ǥ �б�
			glm::vec2 texCoord;
			std::istringstream iss(line.substr(3));
			iss >> texCoord.x >> texCoord.y;
			tempTexCoords.push_back(texCoord);
		}
		else if (line[0] == 'f') { // �� ������ �б�
			std::istringstream iss(line.substr(2));
			std::string vertex;
			std::vector<FaceIndex> faceIndices; // ����, �ؼ� �ε���

			while (iss >> vertex) {
				std::replace(vertex.begin(), vertex.end(), '/', ' ');
				unsigned int v = 0, vt = 0;
				std::istringstream vertexStream(vertex);
				vertexStream >> v >> vt;

				// 1 ��ݿ��� 0 ������� ��ȯ
				faceIndices.push_back({ v - 1, vt > 0 ? vt - 1 : 0 });
			}

			// �ﰢ���� (Triangulation)
			if (faceIndices.size() >= 3) {
				for (size_t i = 1; i < faceIndices.size() - 1; ++i) {
					Face face;
					face.v1 = faceIndices[0].vertexIndex;
					face.v2 = faceIndices[i].vertexIndex;
					face.v3 = faceIndices[i + 1].vertexIndex;

					// �ؼ� ��ǥ ����
					if (faceIndices[0].texCoordIndex < tempTexCoords.size()) {
						model.vertices[face.v1].texCoord = tempTexCoords[faceIndices[0].texCoordIndex];
					}
					else {
						// �ؼ� ��ǥ ���
						model.vertices[face.v1].texCoord = calculate_tex_coord(model.vertices[face.v1].position);
					}
					if (faceIndices[i].texCoordIndex < tempTexCoords.size()) {
						model.vertices[face.v2].texCoord = tempTexCoords[faceIndices[i].texCoordIndex];
					}
					else {
						model.vertices[face.v2].texCoord = calculate_tex_coord(model.vertices[face.v2].position);
					}
					if (faceIndices[i + 1].texCoordIndex < tempTexCoords.size()) {
						model.vertices[face.v3].texCoord = tempTexCoords[faceIndices[i + 1].texCoordIndex];
					}
					else {
						model.vertices[face.v3].texCoord = calculate_tex_coord(model.vertices[face.v3].position);
					}

					model.faces.push_back(face);
				}
			}
		}
	}

	// ��� ���� ��� (���� �ڵ� ����)
	for (const auto& face : model.faces) {
		Vertex& v0 = model.vertices[face.v1];
		Vertex& v1 = model.vertices[face.v2];
		Vertex& v2 = model.vertices[face.v3];

		glm::vec3 edge1 = v1.position - v0.position;
		glm::vec3 edge2 = v2.position - v0.position;

		glm::vec3 faceNormal = (normalDirection == 0)
			? glm::normalize(glm::cross(edge2, edge1))
			: glm::normalize(glm::cross(edge1, edge2));

		v0.normal += faceNormal;
		v1.normal += faceNormal;
		v2.normal += faceNormal;
	}

	for (auto& vertex : model.vertices) {
		if (glm::length(vertex.normal) > 1e-6f) {
			vertex.normal = glm::normalize(vertex.normal);
		}
	}

	file.close();
	std::cout << "OBJ ���� �б� �Ϸ�: "
		<< model.vertices.size() << "���� ����, "
		<< tempTexCoords.size() << "���� �ؼ� ��ǥ, "
		<< model.faces.size() << "���� ��" << std::endl;
}

glm::vec2 calculate_tex_coord(const glm::vec3& position) {
	// �� �߽����κ����� ���� ���� ���
	glm::vec3 direction = glm::normalize(position);

	float theta = atan2(direction.z, direction.x);
	float phi = acos(glm::clamp(direction.y, -1.0f, 1.0f)); 

	// u, v ���
	float u = (theta + glm::pi<float>()) / (2.0f * glm::pi<float>()); 
	float v = phi / glm::pi<float>(); 

	if (u > 1.0f) u -= 1.0f;
	if (u < 0.0f) u += 1.0f;

	const float epsilon = 1e-5f; 
	if (v < epsilon || v > 1.0f - epsilon) {
		u = 0.5f; 
	}

	return glm::vec2(u, v);
} 

void UpdateDirection(float& dir_x, float& dir_z, float angleOffset);

struct Shape {
	GLuint vao, vbo[3];
	glm::vec3 xyz[4] = { glm::vec3(0.0f, 0.0f, 0.0f),
						glm::vec3(0.0f, 0.0f, 0.0f),
						glm::vec3(0.0f, 0.0f, 0.0f),
						glm::vec3(0.0f, 0.0f, 0.0f) };
	glm::vec3 nomal[4] = { glm::vec3(0.0f, 0.2f, 0.7f),
						 glm::vec3(0.0f, 0.2f, 0.7f),
						 glm::vec3(0.0f, 0.2f, 0.7f),
						 glm::vec3(0.0f, 0.2f, 0.7f) };
	glm::vec2 texCoord[4] = {
		glm::vec2(0.0f, 0.0f),
		glm::vec2(1.0f, 0.0f),
		glm::vec2(0.0f, 1.0f),
		glm::vec2(1.0f, 1.0f) 
	};
};

Shape Line_xy;
Shape Line_z;
Shape floor_base; // �ٴ�
Shape wall_base; // ��

float light_r = 0.0f;

glm::vec3 cameraDirection = glm::vec3(0.0f, 0.0f, 0.0f); // ī�޶� �ٶ󺸴� ���� (��������)
glm::vec3 cameraPos = glm::vec3(0.0f, 0.15f, 0.15f); // ī�޶� ��ġ
glm::vec3 worldUp = glm::vec3(0.0f, 1.0f, 0.0f);
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f); // ī�޶��� ���� ����
glm::mat4 view = glm::mat4(1.0f);

float ball_move[2] = { 0.0f }; //�� ������
float yaw = 0.0f; //�¿� ȸ��
float pitch = 0.0f; // ����ȸ��
float radius = 0.15f; // 
float lastX = 600, lastY = 450;
bool firstMouse = true;
const float sensitivity = 0.05f; // ���콺 ����

void CheckPuzzleCondition();
glm::vec3 lightPos = glm::vec3(10.0f, 75.0f, 0.0f); // �� ��ġ

Model model1;
Model model2;
Model model3;
Model model4;
Model model5;
Model model6;
Model model7;
Model model8;
Model model9;
Model model10;
Model model11;
Model model12;
Model model13;
Model model14;
Model model15;
Model model16;

float propeller_r = 0.0f;
bool puzzle_solve = false;

//���ΰ� ��ġ
struct Juinggong
{
	float x = 0.0f;
	float y = 0.9f;
	float z = 0.0f;
	float speed = 0.0f;
	float dir_x = 0;
	float dir_z = 0;

	bool jump = false;
	int jump_time = 0;
	float jump_power = 0.0001f;

	float fail_speed = 0.0001f;
	bool freefall_gravity = true;
	bool ground = false;

	float verticalSpeed = 0.0f; // ���� �ӵ�
	float gravity = 0.001f;    // �߷� ���ӵ�
	float jumpPower = 0.04f;   // �ʱ� ���� �ӵ�

	glm::vec3 velocity = glm::vec3(0.0f); // �ӵ�
	glm::vec3 acceleration = glm::vec3(0.0f, -0.002f, 0.0f); // �߷� ���ӵ�

	bool isFlying = false; // �浹�� ���� ���ư��� ������ ����

};

bool pressedKeys[256] = { false };

struct Floor_base
{
	float x = 0.0f;
	float y = 0.0f;
	float z = 0.0f;

	float sx = 1.0f;
	float sy = 1.0f;
	float sz = 1.0f;

	bool on = false;
	bool falling = false;
	float fallSpeed = 0.0f;
	bool fallingTimerActive = false; // Ÿ�̸� Ȱ��ȭ ����
	float fallingStartTime = 0.0f;   // Ÿ�̸� ���� �ð�

};

struct Wall {
	float x = 0.0f;  // �߽� x ��ǥ
	float y = 0.0f;  // �߽� y ��ǥ
	float z = 0.0f;  // �߽� z ��ǥ

	float width = 1.0f;   // ��
	float height = 1.0f;  // ����
	float depth = 1.0f;   // ����

	bool active = false;  // �� Ȱ��ȭ ����
};

struct button
{
	float x = 0.0f;
	float y = 0.0f;
	float z = 0.0f;

	float sx = 1.0f;
	float sy = 1.0f;
	float sz = 1.0f;

	bool on = false;
};

struct Ball {
	glm::vec3 position;
	glm::vec3 velocity;
	float radius;
	bool ball_active;
};

struct CollisionBox {
	glm::vec3 position; // �ڽ� �߽�
	glm::vec3 size;     // �ڽ� ũ�� (x, y, z)
};

CollisionBox ballBox; // ���� �浹 �ڽ�

bool checkCollision(const CollisionBox& box1, const CollisionBox& box2);

struct Floor_base_move
{
	float x = 0.0f;
	float y = 0.0f;
	float z = 0.0f;

	float sx = 1.0f;
	float sy = 1.0f;
	float sz = 1.0f;

	bool on = false;
	bool move = false;
	bool plus = false;
	float goal1 = 0;
	float goal2 = 0;
	int move_direction = 0; // 0 z, 1 x , 2 y
};

button rects[6]; // ���� - ��ư
Wall walls[30];
Shape background;
Juinggong boy;
Floor_base ff[30];
Floor_base_move ff2[10];
Ball ball[2];


unsigned int texture[10];
int widthImage, heghtImage, numberOfChannel;
float boy_yaw = 0;

char* filetobuf(const char* file) {
	std::ifstream fptr(file, std::ios::binary);
	if (!fptr.is_open()) {
		std::cout << "���� �� �� ����" << std::endl;
		return nullptr;
	}

	// ���� ũ�� ���
	fptr.seekg(0, std::ios::end);
	size_t size = fptr.tellg();
	fptr.seekg(0, std::ios::beg);

	// ���� �Ҵ�
	char* buf = new char[size + 1];

	// ���� �б�
	fptr.read(buf, size);
	fptr.close();

	// �� ���� �߰�
	buf[size] = '\0';

	return buf;
}

void main(int argc, char** argv)	//--- ������ ����ϰ� �ݹ��Լ� ����
{
	srand((unsigned int)time(NULL));
	width = windowWidth;
	height = windowHeight;

	// �ٴ� ����
	ff[0].x = 0;
	ff[0].y = 0;
	ff[0].z = 0;
	ff[0].sx = 3.0f;
	ff[0].sy = 5.0f;
	ff[0].sz = 5.0f;

	//�ٴ�
	ff[1].x = 1.0f;
	ff[1].y = 0.2f;
	ff[1].z = 0;
	ff[1].sx = 0.5f;
	ff[1].sy = 5.0f;
	ff[1].sz = 5.0f;
	//�ٴ�
	ff[2].x = 1.25f;
	ff[2].y = 0.4f;
	ff[2].z = 0.0f;
	ff[2].sx = 0.5f;
	ff[2].sy = 5.0f;
	ff[2].sz = 5.0f;
	//�ٴ�
	ff[3].x = 1.5f;
	ff[3].y = 0.6f;
	ff[3].z = 0;
	ff[3].sx = 0.5f;
	ff[3].sy = 5.0f;
	ff[3].sz = 5.0f;
	//��
	walls[0].x = 0.85f;
	walls[0].y = 0.1f;
	walls[0].z = 0;
	walls[0].depth = 0.05f;
	walls[0].height = 0.33f;
	walls[0].width = 5.0f;
	//��
	walls[1].x = 1.1f;
	walls[1].y = 0.3f;
	walls[1].z = 0;
	walls[1].depth = 0.05f;
	walls[1].height = 0.33f;
	walls[1].width = 5.0f;
	//��
	walls[2].x = 1.35f;
	walls[2].y = 0.5f;
	walls[2].z = 0;
	walls[2].depth = 0.05f;
	walls[2].height = 0.33f;
	walls[2].width = 5.0f;
	//�ٴ�
	ff[7].x = 1.75f;
	ff[7].y = 0.8f;
	ff[7].z = 0;
	ff[7].sx = 0.5f;
	ff[7].sy = 5.0f;
	ff[7].sz = 5.0f;
	//��
	walls[3].x = 1.6f;
	walls[3].y = 0.7f;
	walls[3].z = 0;
	walls[3].depth = 0.05f;
	walls[3].height = 0.33f;
	walls[3].width = 5.0f;
	walls[3].active = true;
	//-----------------------------------------------------------

	//������ �÷���
	ff[9].x = 2.8f;
	ff[9].y = 0.8f;
	ff[9].z = 0.0f;
	ff[9].sx = 3.0f;
	ff[9].sy = 0.2f; // y ���� ũ��
	ff[9].sz = 7.0f; // z ���� ũ��

	//������ ������ 2��
	// ����-------------------------------------
	ff[10].x = 4.0f;
	ff[10].y = 1.0f;
	ff[10].z = -2.5f;
	ff[10].sx = 1.8f;
	ff[10].sy = 0.2f; 
	ff[10].sz = 2.0f; // z ���� ũ��

	ff2[0].x = 5.2f;
	ff2[0].y = 1.0f;
	ff2[0].z = -3.8f;
	ff2[0].sx = 1.8f;
	ff2[0].sy = 0.2f;
	ff2[0].sz = 2.0f;
	ff2[0].move = true;
	ff2[0].on = true;
	ff2[0].goal1 = -6.7f;
	ff2[0].goal2 = -3.0f;
	ff2[0].plus = true;
	ff2[0].move_direction = 0;

	ff2[1].x = 6.4f;
	ff2[1].y = 1.0f;
	ff2[1].z = -6.4f;
	ff2[1].sx = 1.8f;
	ff2[1].sy = 0.2f;
	ff2[1].sz = 2.0f;
	ff2[1].move = true;
	ff2[1].on = true;
	ff2[1].goal1 = -12.0f;
	ff2[1].goal2 = -6.0f;
	ff2[1].plus = true;
	ff2[1].move_direction = 0;

	ff2[2].x = 7.6f;
	ff2[2].y = 1.2f;
	ff2[2].z = -11.0f;
	ff2[2].sx = 1.8f;
	ff2[2].sy = 0.2f;
	ff2[2].sz = 2.0f;
	ff2[2].move = true;
	ff2[2].on = true;
	ff2[2].goal1 = -1.0f;
	ff2[2].goal2 = 2.0f;
	ff2[2].plus = true;
	ff2[2].move_direction = 2;

	ff2[3].x = 10.0f;
	ff2[3].y = 1.0f;
	ff2[3].z = -11.0f;
	ff2[3].sx = 1.8f;
	ff2[3].sy = 0.2f;
	ff2[3].sz = 2.0f;
	ff2[3].move = true;
	ff2[3].on = true;
	ff2[3].goal1 = 11.5f;
	ff2[3].goal2 = 20.0f;
	ff2[3].plus = true;
	ff2[3].move_direction = 1;

	ff2[4].x = 19.0f;
	ff2[4].y = 1.0f;
	ff2[4].z = -7.4f;
	ff2[4].sx = 1.8f;
	ff2[4].sy = 0.2f;
	ff2[4].sz = 9.5f;
	ff2[4].move = false;
	ff2[4].on = true;
	ff2[4].goal1 = 20.0f;
	ff2[4].goal2 = 20.0f;
	ff2[4].plus = true;
	ff2[4].move_direction = 1;

	// ������-------------------------------------------
	ff[11].x = 4.0f;
	ff[11].y = 1.0f;
	ff[11].z = 2.5f;
	ff[11].sx = 1.8f;
	ff[11].sy = 0.2f; // y ���� ũ�� (�ʹ� ū ���� ������ Ȯ��)
	ff[11].sz = 2.0f; // z ���� ũ��

	ff[16].x = 3.5f;
	ff[16].y = 1.2f;
	ff[16].z = 5.0f;
	ff[16].sx = 0.5f;
	ff[16].sy = 0.2f;
	ff[16].sz = 6.0f;

	//�������� ����
	ff[17].x = 4.3f;
	ff[17].y = 1.2f;
	ff[17].z = 6.0f;
	ff[17].sx = 1.0f;
	ff[17].sy = 0.2f;
	ff[17].sz = 1.0f;

	ff[18].x = 5.3f;
	ff[18].y = 1.2f;
	ff[18].z = 6.3f;
	ff[18].sx = 1.0f;
	ff[18].sy = 0.2f;
	ff[18].sz = 1.0f;

	ff[19].x = 6.3f;
	ff[19].y = 1.2f;
	ff[19].z = 6.8f;
	ff[19].sx = 1.0f;
	ff[19].sy = 0.2f;
	ff[19].sz = 1.0f;

	ff[20].x = 7.3f;
	ff[20].y = 1.2f;
	ff[20].z = 7.3f;
	ff[20].sx = 1.0f;
	ff[20].sy = 0.2f;
	ff[20].sz = 1.0f;

	//21,22 - �����̴� �ٴ�
	ff2[5].x = 8.0f;
	ff2[5].y = 1.0f;
	ff2[5].z = 10.0f;
	ff2[5].sx = 1.0f;
	ff2[5].sy = 0.2f;
	ff2[5].sz = 1.0f;
	ff2[5].move = true;
	ff2[5].on = true;
	ff2[5].goal1 = 6.0f;
	ff2[5].goal2 = 14.0f;
	ff2[5].plus = true;
	ff2[5].move_direction = 0;

	ff2[6].x = 30.0f;
	ff2[6].y = 1.0f;
	ff2[6].z = 8.0f;
	ff2[6].sx = 1.8f;
	ff2[6].sy = 0.2f;
	ff2[6].sz = 1.5f;
	ff2[6].move = true;
	ff2[6].on = true;
	ff2[6].goal1 = 23.0f;
	ff2[6].goal2 = 30.0f;
	ff2[6].plus = true;
	ff2[6].move_direction = 1;

	ff2[9].x = 30.0f;
	ff2[9].y = 1.0f;
	ff2[9].z = 6.4f;
	ff2[9].sx = 1.8f;
	ff2[9].sy = 0.2f;
	ff2[9].sz = 1.5f;
	ff2[9].move = true;
	ff2[9].on = true;
	ff2[9].goal1 = 24.0f;
	ff2[9].goal2 = 29.0f;
	ff2[9].plus = true;
	ff2[9].move_direction = 1;


	//�߰� �÷��� ����
	ff[23].x = 17.3f;
	ff[23].y = 1.2f;
	ff[23].z = 10.3f;
	ff[23].sx = 20.0f;
	ff[23].sy = 0.2f;
	ff[23].sz = 5.0f;


	//-------------------------------------------------------------------------------------------
	// x, 
	Line_xy.xyz[0].x = 1.0f;
	Line_xy.xyz[0].y = 0.0f;
	Line_xy.xyz[0].z = 0.0f;
	Line_xy.xyz[1].x = -1.0f;
	Line_xy.xyz[1].y = 0.0f;
	Line_xy.xyz[1].z = 0.0f;
	//y��
	Line_xy.xyz[2].x = 0.0f;
	Line_xy.xyz[2].y = 1.0f;
	Line_xy.xyz[2].z = 0.0f;
	Line_xy.xyz[3].x = 0.0f;
	Line_xy.xyz[3].y = -1.0f;
	Line_xy.xyz[3].z = 0.0f;
	//z��
	Line_z.xyz[0].x = 0.0;
	Line_z.xyz[0].y = 0.0;
	Line_z.xyz[0].z = 1.0;
	Line_z.xyz[1].x = 0.0;
	Line_z.xyz[1].y = 0.0;
	Line_z.xyz[1].z = -1.0;

	// �ٴ�
	floor_base.xyz[0].x = -0.3f;
	floor_base.xyz[0].y = 0.0f;
	floor_base.xyz[0].z = 0.3f;
	floor_base.xyz[1].x = 0.3f;
	floor_base.xyz[1].y = 0.0f;
	floor_base.xyz[1].z = 0.3f;
	floor_base.xyz[2].x = -0.3f;
	floor_base.xyz[2].y = 0.0f;
	floor_base.xyz[2].z = -0.3f;
	floor_base.xyz[3].x = 0.3f;
	floor_base.xyz[3].y = 0.0f;
	floor_base.xyz[3].z = -0.3f;
	for (int i = 0; i < 4; ++i) {
		floor_base.nomal[i].x = 0.0f;
		floor_base.nomal[i].y = 1.0f;
		floor_base.nomal[i].z = 0.0f;
	}
	floor_base.texCoord[0].x = 0.0f;
	floor_base.texCoord[0].y = 0.0f;
	floor_base.texCoord[1].x = 1.0f;
	floor_base.texCoord[1].y = 0.0f;
	floor_base.texCoord[2].x = 0.0f;
	floor_base.texCoord[2].y = 1.0f;
	floor_base.texCoord[3].x = 1.0f;
	floor_base.texCoord[3].y = 1.0f;
	// ��
	wall_base.xyz[0].x = 0.0f;  
	wall_base.xyz[0].y = -0.3f; 
	wall_base.xyz[0].z = 0.3f;  

	wall_base.xyz[1].x = 0.0f;  
	wall_base.xyz[1].y = 0.3f; 
	wall_base.xyz[1].z = 0.3f;  

	wall_base.xyz[2].x = 0.0f;  
	wall_base.xyz[2].y = -0.3f; 
	wall_base.xyz[2].z = -0.3f; 

	wall_base.xyz[3].x = 0.0f;  
	wall_base.xyz[3].y = 0.3f;  
	wall_base.xyz[3].z = -0.3f; 

	//------------------------------------------------------
	//���� �÷���
	ff[12].x = 17.0f;
	ff[12].y = 1.0f;
	ff[12].z = 0.0f;
	ff[12].sx = 3.0f;
	ff[12].sy = 0.2f;
	ff[12].sz = 3.0f;

	//������ �߰� �÷���
	ff[13].x = 10.0f;
	ff[13].y = 1.0f;
	ff[13].z = -10.0f;
	ff[13].sx = 3.0f;
	ff[13].sy = 0.2f;
	ff[13].sz = 3.0f;

	ff[14].x = 10.0f;
	ff[14].y = 1.0f;
	ff[14].z = 10.0f;
	ff[14].sx = 3.0f;
	ff[14].sy = 0.2f;
	ff[14].sz = 3.0f;

	//�����ִ� �ٴ�
	ff[15].x = 22.0f;
	ff[15].y = 1.0f;
	ff[15].z = 0.0f;
	ff[15].sx = 15.0f;
	ff[15].sy = 0.2f;
	ff[15].sz = 15.0f;

	//���� ���̴� ��ư(�簢��)
	// ff[15]�� ũ��� ��ġ�� �������� rects �簢�� ��ġ
	float rectWidth = 2.0f;  // �簢�� ���� ũ��
	float rectDepth = 2.0f;  // �簢�� ���� ũ��
	float rectHeight = 0.1f; // �簢�� �β�

	// ff[15] ũ�� �� ��ġ
	float baseX = ff[15].x;
	float baseY = ff[15].y + 0.01f; // ff[15] ǥ�� �ٷ� ���� �ø���
	float baseZ = ff[15].z;
	float baseWidth = ff[15].sx;
	float baseDepth = ff[15].sz;

	rects[0].x = baseX + 2.0f;
	rects[0].y = baseY;
	rects[0].z = baseZ - 3.0f;

	rects[1].x = baseX;
	rects[1].y = baseY;
	rects[1].z = baseZ - 3.0f;

	rects[2].x = baseX - 2.0f;
	rects[2].y = baseY;
	rects[2].z = baseZ - 3.0f;

	rects[3].x = baseX + 2.0f;
	rects[3].y = baseY;
	rects[3].z = baseZ + 3.0f;

	rects[4].x = baseX;
	rects[4].y = baseY;
	rects[4].z = baseZ + 3.0f;

	rects[5].x = baseX - 2.0f;
	rects[5].y = baseY;
	rects[5].z = baseZ + 3.0f;

	for (int i = 0; i < 4; ++i) {
		wall_base.nomal[i].x = 1.0f;
		wall_base.nomal[i].y = 0.0f;
		wall_base.nomal[i].z = 0.0f;
	}
	wall_base.texCoord[0].x = 0.0f; 
	wall_base.texCoord[0].y = 0.0f;

	wall_base.texCoord[1].x = 1.0f; 
	wall_base.texCoord[1].y = 0.0f;

	wall_base.texCoord[2].x = 0.0f;  
	wall_base.texCoord[2].y = 1.0f;

	wall_base.texCoord[3].x = 1.0f;  
	wall_base.texCoord[3].y = 1.0f;

	read_obj_file("pokeball4.obj", model1, 1);
	read_obj_file("pokeball3.obj", model2, 1);
	read_obj_file("pokeball2.obj", model3, 1);
	read_obj_file("pokeball1.obj", model4, 1);
	read_obj_file("tree1.obj", model5, 1);
	read_obj_file("tree2.obj", model6, 1);
	read_obj_file("sphere.obj", model7, 1);
	read_obj_file("propeller.obj", model8, 1);
	read_obj_file("contanner.obj", model9, 1);
	read_obj_file("keyboard.obj", model10, 1);
	read_obj_file("audio.obj", model11, 1);
	read_obj_file("buger.obj", model12, 1);
	read_obj_file("calculate.obj", model13, 1);
	read_obj_file("game.obj", model14, 1);
	read_obj_file("bett.obj", model15, 1);
	read_obj_file("light.obj", model16, 1);

	//--- ������ �����ϱ�

	glutInit(&argc, argv);					// glut �ʱ�ȭ
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH); // ���÷��� ��� ����
	glutInitWindowPosition(100, 100);		// �������� ��ġ ����
	glutInitWindowSize(width, height);			   // �������� ũ�� ����
	glutCreateWindow("Example1");// ������ ���� (������ �̸�)

	//--- GLEW �ʱ�ȭ�ϱ�
	glewExperimental = GL_TRUE;						// glew �ʱ�ȭ
	if (glewInit() != GLEW_OK)
	{
		std::cerr << "Unable to initialize GLEW" << std::endl;
		exit(EXIT_FAILURE);
	}
	else
		std::cout << "GLEW Initialized\n";

	// --- ���̴� �о�ͼ� ���̴� ���α׷� �����

	glutDisplayFunc(drawScene);    // ��� �Լ��� ����
	glutReshapeFunc(Reshape);		// �ٽ� �׸��� �Լ� ����
	glutKeyboardFunc(Keyboard);  // Ű���� �Է� �ݹ� �Լ�
	glutKeyboardUpFunc(Keyboard_up);
	glutSpecialFunc(SpecialKeyboard);
	glutSetCursor(GLUT_CURSOR_NONE); // ���콺 Ŀ�� �����
	//glutMouseFunc(Mouse);	// ���콺 �Է� �ݹ� �Լ�
	glutPassiveMotionFunc(Motion); // ���콺 �̵� �Է� �ݹ� �Լ�
	glutTimerFunc(5, TimerFunction, 0);

	shaderProgramID = make_shaderProgram(); // ���̴� ���α׷� �����
	InitBuffer();
	InitTexture();
	InitBuffer_obj(model1);
	InitBuffer_obj(model2);
	InitBuffer_obj(model3);
	InitBuffer_obj(model4);
	InitBuffer_obj(model5);
	InitBuffer_obj(model6);
	InitBuffer_obj(model7);
	InitBuffer_obj(model8);
	InitBuffer_obj(model9);
	InitBuffer_obj(model10);
	InitBuffer_obj(model11);
	InitBuffer_obj(model12);
	InitBuffer_obj(model13);
	InitBuffer_obj(model14);
	InitBuffer_obj(model15);
	InitBuffer_obj(model16);

	glutMainLoop();					// �̺�Ʈ ó�� ����
}

// --- ���ؽ� ���̴� ��ü �����
void make_vertexShaders()
{
	GLchar* vertexSource;

	// ���ؽ� ���̴� �о� �����ϰ� ������ �ϱ�
	// filetobuf : ��������� �Լ��� �ؽ�Ʈ�� �о ���ڿ��� �����ϴ� �Լ�

	vertexSource = filetobuf("vertex.glsl");
	vertexShader = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vertexShader, 1, &vertexSource, NULL);
	glCompileShader(vertexShader);

	GLint result;
	GLchar errorLog[512];
	glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &result);
	if (!result)
	{
		glGetShaderInfoLog(vertexShader, 512, NULL, errorLog);
		std::cerr << "ERROR: vertex shader ������ ����\n" << errorLog << std::endl;
		return;
	}
}

// --- �����׸�Ʈ ���̴� ��ü �����
void make_fragmentShaders()
{
	GLchar* fragmentSource;

	// �����׸�Ʈ ���̴� �о� �����ϰ� �������ϱ�
	fragmentSource = filetobuf("fragment.glsl"); // �����׼��̴� �о����
	fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragmentShader, 1, &fragmentSource, NULL);
	glCompileShader(fragmentShader);

	GLint result;
	GLchar errorLog[512];
	glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &result);
	if (!result)
	{
		glGetShaderInfoLog(fragmentShader, 512, NULL, errorLog);
		std::cerr << "ERROR: frag_shader ������ ����\n" << errorLog << std::endl;
		return;
	}
}

// --- ���̴� ���α׷� ����� ���̴� ��ü ��ũ�ϱ�
GLuint make_shaderProgram()
{
	make_vertexShaders();  // ���ؽ� ���̴� �����
	make_fragmentShaders();  // �����׸�Ʈ ���̴� �����

	GLuint shaderID;
	shaderID = glCreateProgram();  // ���̴� ���α׷� �����
	// shader Program
	glAttachShader(shaderID, vertexShader); // ���̴� ���α׷��� ���ؽ� ���̴� ���̱�
	glAttachShader(shaderID, fragmentShader); // ���̴� ���α׷��� �����׸�Ʈ ���̴� ���̱�

	glLinkProgram(shaderID); // ���̴� ���α׷� ��ũ�ϱ�

	// ���̴� �����ϱ�
	glDeleteShader(vertexShader); // ���̴� ��ü�� ���̴� ���α׷��� ��ũ ��������, ���̴� ��ü ��ü�� ���� ����
	glDeleteShader(fragmentShader);

	GLint result;
	GLchar errorLog[512];
	glGetProgramiv(shaderID, GL_LINK_STATUS, &result);
	if (!result) {
		glGetProgramInfoLog(shaderID, 512, NULL, errorLog);
		std::cerr << "ERROR: shader program ���� ����\n" << errorLog << std::endl;
		return false;
	}

	glUseProgram(shaderID); // ������� ���̴� ���α׷� ����ϱ�
	// �������� ���̴� ���α׷� ���� �� �ְ�, �� �� �Ѱ��� ���α׷��� ����Ϸ���
	// glUseProgram �Լ��� ȣ���Ͽ� ��� �� Ư�� ���α׷��� �����Ѵ�.
	// ����ϱ� ������ ȣ���� �� �ִ�.
	return shaderID;
}

GLvoid drawScene()
{
	GLfloat rColor, gColor, bColor;

	rColor = gColor = 1.0;
	bColor = 1.0;
	glClearColor(rColor, gColor, bColor, 1.0f);	 // �������� ��blue�� �� ����
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);				// ������ ������ ��ü��ĥ�ϱ�

	// ������ ���������ο� ���̴� �ҷ�����
	glUseProgram(shaderProgramID);

	// ����
	glUseProgram(shaderProgramID);
	unsigned int lightPosLocation = glGetUniformLocation(shaderProgramID, "lightPos");//--- lightPos �� ����: (0.0, 0.0, 5.0);
	glUniform3f(lightPosLocation, lightPos.x, lightPos.y, lightPos.z);
	unsigned int lightColorLocation = glGetUniformLocation(shaderProgramID, "lightColor"); //--- lightColor �� ����: (1.0, 1.0, 1.0) ���
	glUniform3f(lightColorLocation, 50.0, 50.0, 50.0);
	unsigned int objColorLocation = glGetUniformLocation(shaderProgramID, "objectColor"); //--- object Color�� ����: (1.0, 0.5, 0.3)�� ��
	glUniform3f(objColorLocation, 0.8, 0.8, 0.8);
	unsigned int viewPosLocation = glGetUniformLocation(shaderProgramID, "viewPos"); //--- viewPos �� ����: ī�޶���ġ
	glUniform3f(viewPosLocation, cameraPos.x, cameraPos.y, cameraPos.z);

	// ���� ��ȯ
	glm::mat4 projection = glm::mat4(1.0f);


	//���� ����
	projection = glm::perspective(glm::radians(45.0f), 1.0f, 0.1f, 50.0f); //--- ���� ��������: fovy, aspect, near, far
	projection = glm::translate(projection, glm::vec3(0.0, 0.0, -2.0)); //--- ������z���̵�

	unsigned int projectionLocation = glGetUniformLocation(shaderProgramID, "projectionTransform");
	glUniformMatrix4fv(projectionLocation, 1, GL_FALSE, &projection[0][0]);

	// ��ȯ ��� �����
	glm::mat4 RR = glm::mat4(1.0f);
	glm::mat4 RR1 = glm::mat4(1.0f);
	glm::mat4 RR2 = glm::mat4(1.0f);
	glm::mat4 T = glm::mat4(1.0f);
	glm::mat4 LT = glm::mat4(1.0f);
	glm::mat4 LR = glm::mat4(1.0f);
	glm::mat4 S = glm::mat4(1.0f);
	glm::mat4 CS = glm::mat4(1.0f);
	glm::mat4 CT1 = glm::mat4(1.0f);
	glm::mat4 CS2 = glm::mat4(1.0f);
	glm::mat4 JuingGong_T = glm::mat4(1.0f);
	glm::mat4 JuingGong_R = glm::mat4(1.0f);
	glm::mat4 Floor_1_T = glm::mat4(1.0f);
	glm::mat4 Floor_2_T = glm::mat4(1.0f);
	glm::mat4 Floor_3_T = glm::mat4(1.0f);
	glm::mat4 Floor_4_T = glm::mat4(1.0f);
	glm::mat4 Floor_5_T = glm::mat4(1.0f);
	glm::mat4 Floor_6_T = glm::mat4(1.0f);
	glm::mat4 Floor_7_T = glm::mat4(1.0f);
	glm::mat4 Floor_8_T = glm::mat4(1.0f);
	glm::mat4 Floor_9_T = glm::mat4(1.0f);
	glm::mat4 Floor_10_T = glm::mat4(1.0f);
	glm::mat4 Floor_11_T = glm::mat4(1.0f);
	glm::mat4 Floor_12_T = glm::mat4(1.0f);
	glm::mat4 Floor_13_T = glm::mat4(1.0f);
	glm::mat4 Floor_14_T = glm::mat4(1.0f);
	glm::mat4 Floor_15_T = glm::mat4(1.0f);
	glm::mat4 Floor_16_T = glm::mat4(1.0f);
	glm::mat4 Floor_17_T = glm::mat4(1.0f);
	glm::mat4 Floor_18_T = glm::mat4(1.0f);
	glm::mat4 Floor_19_T = glm::mat4(1.0f);
	glm::mat4 Floor_20_T = glm::mat4(1.0f);
	glm::mat4 Floor_21_T = glm::mat4(1.0f);
	glm::mat4 Floor_22_T = glm::mat4(1.0f);
	glm::mat4 Floor_23_T = glm::mat4(1.0f);
	glm::mat4 Floor_24_T = glm::mat4(1.0f);
	glm::mat4 Floor_25_T = glm::mat4(1.0f);
	glm::mat4 CS3 = glm::mat4(1.0f);
	glm::mat4 CS4 = glm::mat4(1.0f);
	glm::mat4 CS5 = glm::mat4(1.0f);
	glm::mat4 CS6 = glm::mat4(1.0f);
	glm::mat4 CS6_1 = glm::mat4(1.0f);
	glm::mat4 CS7 = glm::mat4(1.0f);
	glm::mat4 CS8 = glm::mat4(1.0f);
	glm::mat4 CS9 = glm::mat4(1.0f);
	glm::mat4 CS10 = glm::mat4(1.0f);
	glm::mat4 CS11 = glm::mat4(1.0f);
	glm::mat4 CS12 = glm::mat4(1.0f);
	glm::mat4 CS13 = glm::mat4(1.0f);
	glm::mat4 CS14 = glm::mat4(1.0f);
	glm::mat4 CS15 = glm::mat4(1.0f);
	glm::mat4 CS16 = glm::mat4(1.0f);
	glm::mat4 CS17 = glm::mat4(1.0f);
	glm::mat4 CS18 = glm::mat4(1.0f);
	glm::mat4 CS19 = glm::mat4(1.0f);
	glm::mat4 CS20 = glm::mat4(1.0f);
	glm::mat4 CS21 = glm::mat4(1.0f);
	glm::mat4 CS22 = glm::mat4(1.0f);
	glm::mat4 CS23 = glm::mat4(1.0f);
	glm::mat4 CS24 = glm::mat4(1.0f);
	glm::mat4 CS25 = glm::mat4(1.0f);
	glm::mat4 BackGround = glm::mat4(1.0f);
	glm::mat4 BackGround_S = glm::mat4(1.0f);
	glm::mat4 Tree_T = glm::mat4(1.0f);
	glm::mat4 Tree_S = glm::mat4(1.0f);


	unsigned int modelLocation = glGetUniformLocation(shaderProgramID, "modelTransform");

	// ��ī�̹ڽ� �׸���
	glDepthFunc(GL_LEQUAL);  // ��ī�̹ڽ��� �׻� ���� ���ʿ� �׷������� ���� �׽�Ʈ ����

	// �ؽ�ó ���ε�
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, texture[0]);
	glUniform1i(glGetUniformLocation(shaderProgramID, "skyboxTexture"), 0);

	// VAO�� ���ε��ϰ� ��ī�̹ڽ� �׸���
	BackGround = glm::translate(BackGround, glm::vec3(boy.x, boy.y, boy.z));
	BackGround_S = glm::scale(BackGround_S, glm::vec3(2.0, 2.0, 2.0));
	RR = BackGround * BackGround_S;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));

	//glBindVertexArray(background.vao);
	//glDrawArrays(GL_TRIANGLES, 0, 36);
	glUniform3f(objColorLocation, 10.0, 10.0, 10.0);

	glBindVertexArray(model7.vao);
	glDrawElements(GL_TRIANGLES, model7.indices.size(), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);
	glBindTexture(GL_TEXTURE_2D, 0);

	glDepthFunc(GL_LESS);  // ���� �׽�Ʈ�� �⺻������ �ǵ���

	unsigned int viewLocation = glGetUniformLocation(shaderProgramID, "viewTransform");
	glUniformMatrix4fv(viewLocation, 1, GL_FALSE, &view[0][0]);


	RR1 = glm::rotate(RR1, glm::radians(0.0f), glm::vec3(1.0, 0.0, 0.0));
	RR2 = glm::rotate(RR2, glm::radians(0.0f), glm::vec3(0.0, 1.0, 0.0));
	RR = RR1 * RR2;


	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));

	glPointSize(3.0);
	glLineWidth(1.0);
	glEnable(GL_DEPTH_TEST);

	// ������ Ÿ�� �ٴ�
	
	// �ٴ�1
	glUniform3f(objColorLocation, 1.0, 0.0, 0.0);
	Floor_1_T = glm::translate(Floor_1_T, glm::vec3(ff[0].x, ff[0].y, ff[0].z));
	CS6_1 = glm::scale(CS6_1, glm::vec3(ff[0].sx, ff[0].sy, ff[0].sz));
	RR = RR1 * RR2 * Floor_1_T * CS6_1;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));


	glBindVertexArray(floor_base.vao);
	glDrawArrays(GL_TRIANGLES, 0, 3);
	glDrawArrays(GL_TRIANGLES, 1, 3);
	glBindVertexArray(0);

	// ���----------------------------------------------------------
	glUniform3f(objColorLocation, 1.0, 1.0, 1.0);
	Floor_2_T = glm::translate(Floor_2_T, glm::vec3(ff[1].x, ff[1].y, ff[1].z));
	CS2 = glm::scale(CS3, glm::vec3(ff[1].sx, ff[1].sy, ff[1].sz));
	RR = RR1 * RR2 * Floor_2_T * CS2;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));

	glBindVertexArray(floor_base.vao);
	glDrawArrays(GL_TRIANGLES, 0, 3);
	glDrawArrays(GL_TRIANGLES, 1, 3);
	glBindVertexArray(0);


	glUniform3f(objColorLocation, 0.0, 0.0, 1.0);
	Floor_3_T = glm::translate(Floor_3_T, glm::vec3(ff[2].x, ff[2].y, ff[2].z));
	CS3 = glm::scale(CS3, glm::vec3(ff[2].sx, ff[2].sy, ff[2].sz));
	RR = RR1 * RR2 * Floor_3_T * CS3;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));

	glBindVertexArray(floor_base.vao);
	glDrawArrays(GL_TRIANGLES, 0, 3);
	glDrawArrays(GL_TRIANGLES, 1, 3);
	glBindVertexArray(0);


	glUniform3f(objColorLocation, 0.0, 1.0, 0.0);
	Floor_4_T = glm::translate(Floor_4_T, glm::vec3(ff[3].x, ff[3].y, ff[3].z));
	CS4 = glm::scale(CS4, glm::vec3(ff[3].sx, ff[3].sy, ff[3].sz));
	RR = RR1 * RR2 * Floor_4_T * CS4;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));

	glBindVertexArray(floor_base.vao);
	glDrawArrays(GL_TRIANGLES, 0, 3);
	glDrawArrays(GL_TRIANGLES, 1, 3);
	glBindVertexArray(0);

	glUniform3f(objColorLocation, 0.0, 0.5, 0.5);
	Floor_5_T = glm::translate(Floor_5_T, glm::vec3(ff[7].x, ff[7].y, ff[7].z));
	CS5 = glm::scale(CS5, glm::vec3(ff[7].sx, ff[7].sy, ff[7].sz));
	RR = RR1 * RR2 * Floor_5_T * CS5;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));

	glBindVertexArray(floor_base.vao);
	glDrawArrays(GL_TRIANGLES, 0, 3);
	glDrawArrays(GL_TRIANGLES, 1, 3);
	glBindVertexArray(0);

	glUniform3f(objColorLocation, 1.0, 0.0, 0.0);
	Floor_6_T = glm::translate(Floor_6_T, glm::vec3(ff[9].x, ff[9].y, ff[9].z));
	CS6 = glm::scale(CS6, glm::vec3(ff[9].sx, ff[9].sy, ff[9].sz));
	RR = RR1 * RR2 * Floor_6_T * CS6;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));

	/*
	glBindVertexArray(floor_base.vao);
	glDrawArrays(GL_TRIANGLES, 0, 3);
	glDrawArrays(GL_TRIANGLES, 1, 3);
	glBindVertexArray(0);
	*/
	glm::mat4 mid_Object_5_S = glm::mat4(1.0f);
	glm::mat4 mid_Object_5_R = glm::mat4(1.0f);
	glm::mat4 mid_Object_5_T = glm::mat4(1.0f);
	glm::mat4 mid_Object_4_S = glm::mat4(1.0f);
	glm::mat4 mid_Object_4_R = glm::mat4(1.0f);
	glm::mat4 mid_Object_4_T = glm::mat4(1.0f);
	glm::mat4 mid_Object_3_S = glm::mat4(1.0f);
	glm::mat4 mid_Object_3_T = glm::mat4(1.0f);

	mid_Object_5_S = glm::scale(mid_Object_5_S, glm::vec3(0.05, 0.04, 0.0322));
	mid_Object_5_R = glm::rotate(mid_Object_5_R, glm::radians(90.0f), glm::vec3(0.0, 1.0, 0.0));
	mid_Object_5_T = glm::translate(mid_Object_5_T, glm::vec3(0.9f, -0.07f, -0.0f));
	RR = RR1 * RR2 * mid_Object_5_T * Floor_6_T * mid_Object_5_R * mid_Object_5_S;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));

	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, texture[5]);
	glUniform1i(glGetUniformLocation(shaderProgramID, "objectTexture"), 0);
	glUniform3f(objColorLocation, 1.0, 1.0, 1.0);
	glBindVertexArray(model11.vao);
	glDrawElements(GL_TRIANGLES, model11.indices.size(), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);
	glBindTexture(GL_TEXTURE_2D, 0);


	//������ ����
	glUniform3f(objColorLocation, 0.7, 0.7, 0.7);
	Floor_7_T = glm::translate(Floor_7_T, glm::vec3(ff[10].x, ff[10].y, ff[10].z));
	CS7 = glm::scale(CS7, glm::vec3(ff[10].sx, ff[10].sy, ff[10].sz));
	RR = RR1 * RR2 * Floor_7_T * CS7;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));
	/*
	glBindVertexArray(floor_base.vao);
	glDrawArrays(GL_TRIANGLES, 0, 3);
	glDrawArrays(GL_TRIANGLES, 1, 3);
	glBindVertexArray(0);
	*/
	mid_Object_4_S = glm::scale(mid_Object_4_S, glm::vec3(0.011, 0.012, 0.012));
	mid_Object_4_R = glm::rotate(mid_Object_4_R, glm::radians(-150.0f), glm::vec3(1.0, 0.0, 0.0));
	mid_Object_4_T = glm::translate(mid_Object_4_T, glm::vec3(0.0f, -0.4f, 0.5f));
	RR = RR1 * RR2 * mid_Object_4_T * Floor_7_T * mid_Object_4_R * mid_Object_4_S;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));

	glUniform3f(objColorLocation, 0.8, 0.8, 0.8);
	glBindVertexArray(model14.vao);
	glDrawElements(GL_TRIANGLES, model14.indices.size(), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);

	glUniform3f(objColorLocation, 0.7, 0.7, 0.7);
	Floor_8_T = glm::translate(Floor_8_T, glm::vec3(ff[11].x, ff[11].y, ff[11].z));
	CS8 = glm::scale(CS8, glm::vec3(ff[11].sx, ff[11].sy, ff[11].sz));
	RR = RR1 * RR2 * Floor_8_T * CS8;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));
	/*
	glBindVertexArray(floor_base.vao);
	glDrawArrays(GL_TRIANGLES, 0, 3);
	glDrawArrays(GL_TRIANGLES, 1, 3);
	glBindVertexArray(0);
	*/
	RR = RR1 * RR2 * mid_Object_4_T * Floor_8_T * mid_Object_4_R * mid_Object_4_S;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));

	glUniform3f(objColorLocation, 0.8, 0.8, 0.8);
	glBindVertexArray(model14.vao);
	glDrawElements(GL_TRIANGLES, model14.indices.size(), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);

	//������ �߰�
	glUniform3f(objColorLocation, 0.7, 0.7, 0.7);
	Floor_10_T = glm::translate(Floor_10_T, glm::vec3(ff[13].x, ff[13].y, ff[13].z));
	CS10 = glm::scale(CS10, glm::vec3(ff[13].sx, ff[13].sy, ff[13].sz));
	RR = RR1 * RR2 * Floor_10_T * CS10;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));
	/*
	glBindVertexArray(floor_base.vao);
	glDrawArrays(GL_TRIANGLES, 0, 3);
	glDrawArrays(GL_TRIANGLES, 1, 3);
	glBindVertexArray(0);
	*/
	mid_Object_3_S = glm::scale(mid_Object_3_S, glm::vec3(0.018, 0.020, 0.020));
	mid_Object_3_T = glm::translate(mid_Object_3_T, glm::vec3(0.0f, -0.65f, 0.8f));

	RR = RR1 * RR2 * mid_Object_3_T * Floor_10_T * mid_Object_4_R * mid_Object_3_S;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));

	glUniform3f(objColorLocation, 0.8, 0.8, 0.8);
	glBindVertexArray(model14.vao);
	glDrawElements(GL_TRIANGLES, model14.indices.size(), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);

	glUniform3f(objColorLocation, 0.7, 0.7, 0.7);
	Floor_11_T = glm::translate(Floor_11_T, glm::vec3(ff[14].x, ff[14].y, ff[14].z));
	CS11 = glm::scale(CS11, glm::vec3(ff[14].sx, ff[14].sy, ff[14].sz));
	RR = RR1 * RR2 * Floor_11_T * CS11;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));
	/*
	glBindVertexArray(floor_base.vao);
	glDrawArrays(GL_TRIANGLES, 0, 3);
	glDrawArrays(GL_TRIANGLES, 1, 3);
	glBindVertexArray(0);
	*/
	RR = RR1 * RR2 * mid_Object_3_T * Floor_11_T * mid_Object_4_R * mid_Object_3_S;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));

	glUniform3f(objColorLocation, 0.8, 0.8, 0.8);
	glBindVertexArray(model14.vao);
	glDrawElements(GL_TRIANGLES, model14.indices.size(), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);

	//���� �ִ� �ٴ�
	glUniform3f(objColorLocation, 0.7, 0.7, 0.7);
	Floor_12_T = glm::translate(Floor_12_T, glm::vec3(ff[15].x, ff[15].y, ff[15].z));
	CS12 = glm::scale(CS12, glm::vec3(ff[15].sx, ff[15].sy, ff[15].sz));
	RR = RR1 * RR2 * Floor_12_T * CS12;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));

	glBindVertexArray(floor_base.vao);
	glDrawArrays(GL_TRIANGLES, 0, 3);
	glDrawArrays(GL_TRIANGLES, 1, 3);
	glBindVertexArray(0);

	// ���� ��
	glm::mat4 left_1_T = glm::mat4(1.0f);
	glm::mat4 left_1_S = glm::mat4(1.0f);
	glm::mat4 left_2_T = glm::mat4(1.0f);
	glm::mat4 left_2_S = glm::mat4(1.0f);
	glm::mat4 left_3_T = glm::mat4(1.0f);
	glm::mat4 left_3_S = glm::mat4(1.0f);
	glm::mat4 left_4_T = glm::mat4(1.0f);
	glm::mat4 left_4_S = glm::mat4(1.0f);
	glm::mat4 left_5_T = glm::mat4(1.0f);
	glm::mat4 left_5_S = glm::mat4(1.0f);
	glm::mat4 left_Object_5_S = glm::mat4(1.0f);
	glm::mat4 left_Object_5_R = glm::mat4(1.0f);
	glm::mat4 left_Object_5_T = glm::mat4(1.0f);
	glm::mat4 left_Object_1_S = glm::mat4(1.0f);
	glm::mat4 left_Object_1_R = glm::mat4(1.0f);
	glm::mat4 left_Object_1_R2 = glm::mat4(1.0f);
	glm::mat4 left_Object_1_T = glm::mat4(1.0f);
	glm::mat4 left_Object_2_S = glm::mat4(1.0f);
	glm::mat4 left_Object_2_T = glm::mat4(1.0f);

	glUniform3f(objColorLocation, 0.9, 0.9, 0.0);
	left_1_T = glm::translate(left_1_T, glm::vec3(ff2[0].x, ff2[0].y, ff2[0].z));
	left_1_S = glm::scale(left_1_S, glm::vec3(ff2[0].sx, ff2[0].sy, ff2[0].sz));
	RR = RR1 * RR2 * left_1_T * left_1_S;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));
	/*
	glBindVertexArray(floor_base.vao);
	glDrawArrays(GL_TRIANGLES, 0, 3);
	glDrawArrays(GL_TRIANGLES, 1, 3);
	glBindVertexArray(0);
	*/

	left_Object_1_S = glm::scale(left_Object_1_S, glm::vec3(0.06, 0.06, 0.04));
	left_Object_1_R = glm::rotate(left_Object_1_R, glm::radians(90.0f), glm::vec3(1.0, 0.0, 0.0));
	left_Object_1_R2 = glm::rotate(left_Object_1_R2, glm::radians(180.0f), glm::vec3(0.0, 0.0, 1.0));
	left_Object_1_T = glm::translate(left_Object_1_T, glm::vec3(-0.15f, -0.55f, 0.2f));
	RR = RR1 * RR2 * left_Object_1_T * left_1_T * left_Object_1_R2 * left_Object_1_R * left_Object_1_S;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));


	glUniform3f(objColorLocation, 1.0, 1.0, 0.0);
	glBindVertexArray(model12.vao);
	glDrawElements(GL_TRIANGLES, model12.indices.size(), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);

	glUniform3f(objColorLocation, 0.9, 0.9, 0.0);
	left_2_T = glm::translate(left_2_T, glm::vec3(ff2[1].x, ff2[1].y, ff2[1].z));
	left_2_S = glm::scale(left_2_S, glm::vec3(ff2[1].sx, ff2[1].sy, ff2[1].sz));
	RR = RR1 * RR2 * left_2_T * left_2_S;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));
	/*
	glBindVertexArray(floor_base.vao);
	glDrawArrays(GL_TRIANGLES, 0, 3);
	glDrawArrays(GL_TRIANGLES, 1, 3);
	glBindVertexArray(0);
	*/
	RR = RR1 * RR2 * left_Object_1_T * left_2_T * left_Object_1_R2 * left_Object_1_R * left_Object_1_S;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));


	glUniform3f(objColorLocation, 0.0, 1.0, 0.0);
	glBindVertexArray(model12.vao);
	glDrawElements(GL_TRIANGLES, model12.indices.size(), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);


	glUniform3f(objColorLocation, 0.0, 0.9, 0.0);
	left_3_T = glm::translate(left_3_T, glm::vec3(ff2[2].x, ff2[2].y, ff2[2].z));
	left_3_S = glm::scale(left_3_S, glm::vec3(ff2[2].sx, ff2[2].sy, ff2[2].sz));
	RR = RR1 * RR2 * left_3_T * left_3_S;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));
	/*
	glBindVertexArray(floor_base.vao);
	glDrawArrays(GL_TRIANGLES, 0, 3);
	glDrawArrays(GL_TRIANGLES, 1, 3);
	glBindVertexArray(0);
	*/
	RR = RR1 * RR2 * left_Object_1_T * left_3_T * left_Object_1_R2 * left_Object_1_R * left_Object_1_S;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));

	glUniform3f(objColorLocation, 1.0, 0.4, 0.0);
	glBindVertexArray(model12.vao);
	glDrawElements(GL_TRIANGLES, model12.indices.size(), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);

	glUniform3f(objColorLocation, 0.0, 0.9, 0.0);
	left_4_T = glm::translate(left_4_T, glm::vec3(ff2[3].x, ff2[3].y, ff2[3].z));
	left_4_S = glm::scale(left_4_S, glm::vec3(ff2[3].sx, ff2[3].sy, ff2[3].sz));
	RR = RR1 * RR2 * left_4_T * left_4_S;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));
	/*
	glBindVertexArray(floor_base.vao);
	glDrawArrays(GL_TRIANGLES, 0, 3);
	glDrawArrays(GL_TRIANGLES, 1, 3);
	glBindVertexArray(0);
	*/
	RR = RR1 * RR2 * left_Object_1_T * left_4_T * left_Object_1_R2 * left_Object_1_R * left_Object_1_S;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));

	glUniform3f(objColorLocation, 0.0, 0.2, 1.0);
	glBindVertexArray(model12.vao);
	glDrawElements(GL_TRIANGLES, model12.indices.size(), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);

	glUniform3f(objColorLocation, 0.0, 1.0, 1.0);
	left_5_T = glm::translate(left_5_T, glm::vec3(ff2[4].x, ff2[4].y, ff2[4].z));
	left_5_S = glm::scale(left_5_S, glm::vec3(ff2[4].sx, ff2[4].sy, ff2[4].sz));
	RR = RR1 * RR2 * left_5_T * left_5_S;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));
	/*
	glBindVertexArray(floor_base.vao);
	glDrawArrays(GL_TRIANGLES, 0, 3);
	glDrawArrays(GL_TRIANGLES, 1, 3);
	glBindVertexArray(0);
	*/
	left_Object_5_S = glm::scale(left_Object_5_S, glm::vec3(0.0505, 0.03, 0.02));
	left_Object_5_R = glm::rotate(left_Object_5_R, glm::radians(90.0f), glm::vec3(0.0, 1.0, 0.0));
	left_Object_5_T = glm::translate(left_Object_5_T, glm::vec3(-0.4f, -0.78f, -0.04f));
	RR = RR1 * RR2 * left_Object_5_T * left_5_T * left_Object_5_R * left_Object_5_S;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));

	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, texture[3]);
	glUniform1i(glGetUniformLocation(shaderProgramID, "objectTexture"), 0);
	glUniform3f(objColorLocation, 1.0, 1.0, 1.0);
	glBindVertexArray(model9.vao);
	glDrawElements(GL_TRIANGLES, model9.indices.size(), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);
	glBindTexture(GL_TEXTURE_2D, 0);

	//  �����ʱ�
	glm::mat4 right_Object_1_S = glm::mat4(1.0f);
	glm::mat4 right_Object_1_R = glm::mat4(1.0f);
	glm::mat4 right_Object_1_T = glm::mat4(1.0f);
	glm::mat4 right_Object_2_S = glm::mat4(1.0f);
	glm::mat4 right_Object_2_R = glm::mat4(1.0f);
	glm::mat4 right_Object_2_T = glm::mat4(1.0f);
	glm::mat4 right_Object_5_S = glm::mat4(1.0f);
	glm::mat4 right_Object_5_R = glm::mat4(1.0f);
	glm::mat4 right_Object_5_R2 = glm::mat4(1.0f);
	glm::mat4 right_Object_5_T = glm::mat4(1.0f);
	
	 
	//ff[11]���� ������ �� ����
	glUniform3f(objColorLocation, 0.7, 0.7, 0.7);
	Floor_13_T = glm::translate(Floor_13_T, glm::vec3(ff[16].x, ff[16].y, ff[16].z));
	CS13 = glm::scale(CS13, glm::vec3(ff[16].sx, ff[16].sy, ff[16].sz));
	RR = RR1 * RR2 * Floor_13_T * CS13;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));
	/*
	glBindVertexArray(floor_base.vao);
	glDrawArrays(GL_TRIANGLES, 0, 3);
	glDrawArrays(GL_TRIANGLES, 1, 3);
	glBindVertexArray(0);
	*/
	right_Object_2_S = glm::scale(right_Object_2_S, glm::vec3(0.014, 0.012, 0.0095));
	right_Object_2_R = glm::rotate(right_Object_2_R, glm::radians(0.0f), glm::vec3(0.0, 1.0, 0.0));
	right_Object_2_T = glm::translate(left_Object_2_T, glm::vec3(0.17f, -0.1f, -0.0f));
	RR = RR1 * RR2 * right_Object_2_T * Floor_13_T * right_Object_2_R * right_Object_2_S;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));

	glUniform3f(objColorLocation, 1.0, 1.0, 1.0);
	glBindVertexArray(model15.vao);
	glDrawElements(GL_TRIANGLES, model15.indices.size(), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);


	//������ �������� ����1
	glUniform3f(objColorLocation, 0.7, 0.7, 0.7);
	Floor_14_T = glm::translate(Floor_14_T, glm::vec3(ff[17].x, ff[17].y, ff[17].z));
	CS14 = glm::scale(CS14, glm::vec3(ff[17].sx, ff[17].sy, ff[17].sz));
	RR = RR1 * RR2 * Floor_14_T * CS14;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));
	/*
	glBindVertexArray(floor_base.vao);
	glDrawArrays(GL_TRIANGLES, 0, 3);
	glDrawArrays(GL_TRIANGLES, 1, 3);
	glBindVertexArray(0);
	*/
	right_Object_1_S = glm::scale(right_Object_1_S, glm::vec3(0.014, 0.012, 0.012));
	right_Object_1_R = glm::rotate(right_Object_1_R, glm::radians(0.0f), glm::vec3(0.0, 1.0, 0.0));
	right_Object_1_T = glm::translate(left_Object_1_T, glm::vec3(0.15f, 0.54f, -0.15f));
	RR = RR1 * RR2 * right_Object_1_T * Floor_14_T * right_Object_1_R * right_Object_1_S;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));

	glUniform3f(objColorLocation, 1.0, 0.0, 0.0);
	glBindVertexArray(model13.vao);
	glDrawElements(GL_TRIANGLES, model13.indices.size(), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);

	//������ �������� ����2
	glUniform3f(objColorLocation, 0.7, 0.7, 0.7);
	Floor_15_T = glm::translate(Floor_15_T, glm::vec3(ff[18].x, ff[18].y, ff[18].z));
	CS15 = glm::scale(CS15, glm::vec3(ff[18].sx, ff[18].sy, ff[18].sz));
	RR = RR1 * RR2 * Floor_15_T * CS15;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));
	/*
	glBindVertexArray(floor_base.vao);
	glDrawArrays(GL_TRIANGLES, 0, 3);
	glDrawArrays(GL_TRIANGLES, 1, 3);
	glBindVertexArray(0);
	*/
	RR = RR1 * RR2 * right_Object_1_T * Floor_15_T * right_Object_1_R * right_Object_1_S;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));

	glUniform3f(objColorLocation, 1.0, 1.0, 0.0);
	glBindVertexArray(model13.vao);
	glDrawElements(GL_TRIANGLES, model13.indices.size(), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);

	//������ �������� ����3
	glUniform3f(objColorLocation, 0.7, 0.7, 0.7);
	Floor_16_T = glm::translate(Floor_16_T, glm::vec3(ff[19].x, ff[19].y, ff[19].z));
	CS16 = glm::scale(CS16, glm::vec3(ff[19].sx, ff[19].sy, ff[19].sz));
	RR = RR1 * RR2 * Floor_16_T * CS16;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));
	/*
	glBindVertexArray(floor_base.vao);
	glDrawArrays(GL_TRIANGLES, 0, 3);
	glDrawArrays(GL_TRIANGLES, 1, 3);
	glBindVertexArray(0);
	*/
	RR = RR1 * RR2 * right_Object_1_T * Floor_16_T * right_Object_1_R * right_Object_1_S;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));

	glUniform3f(objColorLocation, 0.0, 1.0, 0.4);
	glBindVertexArray(model13.vao);
	glDrawElements(GL_TRIANGLES, model13.indices.size(), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);

	////������ �������� ����4
	glUniform3f(objColorLocation, 0.7, 0.7, 0.7);
	Floor_17_T = glm::translate(Floor_17_T, glm::vec3(ff[20].x, ff[20].y, ff[20].z));
	CS17 = glm::scale(CS17, glm::vec3(ff[20].sx, ff[20].sy, ff[20].sz));
	RR = RR1 * RR2 * Floor_17_T * CS17;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));
	/*
	glBindVertexArray(floor_base.vao);
	glDrawArrays(GL_TRIANGLES, 0, 3);
	glDrawArrays(GL_TRIANGLES, 1, 3);
	glBindVertexArray(0);
	*/
	RR = RR1 * RR2 * right_Object_1_T * Floor_17_T * right_Object_1_R * right_Object_1_S;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));

	glUniform3f(objColorLocation, 0.0, 1.0, 1.0);
	glBindVertexArray(model13.vao);
	glDrawElements(GL_TRIANGLES, model13.indices.size(), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);

	//�����̴� ���� �߰� �÷��� ��, �� �÷��� �� 1,2
	glUniform3f(objColorLocation, 0.7, 0.7, 0.7);
	Floor_22_T = glm::translate(Floor_22_T, glm::vec3(ff2[5].x, ff2[5].y, ff2[5].z));
	CS22 = glm::scale(CS22, glm::vec3(ff2[5].sx, ff2[5].sy, ff2[5].sz));
	RR = RR1 * RR2 * Floor_22_T * CS22;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));
	/*
	glBindVertexArray(floor_base.vao);
	glDrawArrays(GL_TRIANGLES, 0, 3);
	glDrawArrays(GL_TRIANGLES, 1, 3);
	glBindVertexArray(0);
	*/
	left_Object_2_S = glm::scale(left_Object_2_S, glm::vec3(0.035, 0.035, 0.04));
	left_Object_2_T = glm::translate(left_Object_2_T, glm::vec3(-0.1f, -0.55f, 0.1f));


	RR = RR1 * RR2 * left_Object_2_T * Floor_22_T * left_Object_1_R2 * left_Object_1_R * left_Object_2_S;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));

	glUniform3f(objColorLocation, 0.0, 0.5, 1.0);
	glBindVertexArray(model12.vao);
	glDrawElements(GL_TRIANGLES, model12.indices.size(), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);

	glUniform3f(objColorLocation, 0.7, 0.7, 0.7);
	Floor_23_T = glm::translate(Floor_23_T, glm::vec3(ff2[6].x, ff2[6].y, ff2[6].z));
	CS23 = glm::scale(CS23, glm::vec3(ff2[6].sx, ff2[6].sy, ff2[6].sz));
	RR = RR1 * RR2 * Floor_23_T * CS23;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));
	/*
	glBindVertexArray(floor_base.vao);
	glDrawArrays(GL_TRIANGLES, 0, 3);
	glDrawArrays(GL_TRIANGLES, 1, 3);
	glBindVertexArray(0);
	*/
	RR = RR1 * RR2 * left_Object_1_T * Floor_23_T * left_Object_1_R2 * left_Object_1_R * left_Object_1_S;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));


	glUniform3f(objColorLocation, 0.5, 1.0, 0.0);
	glBindVertexArray(model12.vao);
	glDrawElements(GL_TRIANGLES, model12.indices.size(), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);

	glUniform3f(objColorLocation, 0.7, 0.7, 0.7);
	Floor_24_T = glm::translate(Floor_24_T, glm::vec3(ff2[9].x, ff2[9].y, ff2[9].z));
	CS24 = glm::scale(CS24, glm::vec3(ff2[9].sx, ff2[9].sy, ff2[9].sz));
	RR = RR1 * RR2 * Floor_24_T * CS24;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));
	/*
	glBindVertexArray(floor_base.vao);
	glDrawArrays(GL_TRIANGLES, 0, 3);
	glDrawArrays(GL_TRIANGLES, 1, 3);
	glBindVertexArray(0);
	*/
	RR = RR1 * RR2 * left_Object_1_T * Floor_24_T * left_Object_1_R2 * left_Object_1_R * left_Object_1_S;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));


	glUniform3f(objColorLocation, 1.0, 0.0, 0.5);
	glBindVertexArray(model12.vao);
	glDrawElements(GL_TRIANGLES, model12.indices.size(), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);

	//�÷��� ��
	glUniform3f(objColorLocation, 0.7, 0.7, 0.7);
	Floor_21_T = glm::translate(Floor_21_T, glm::vec3(ff[23].x, ff[23].y, ff[23].z));
	CS21 = glm::scale(CS21, glm::vec3(ff[23].sx, ff[23].sy, ff[23].sz));
	RR = RR1 * RR2 * Floor_21_T * CS21;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));
	/*
	glBindVertexArray(floor_base.vao);
	glDrawArrays(GL_TRIANGLES, 0, 3);
	glDrawArrays(GL_TRIANGLES, 1, 3);
	glBindVertexArray(0);
	*/
	right_Object_5_S = glm::scale(right_Object_5_S, glm::vec3(0.535, 0.42, 0.5));
	right_Object_5_R = glm::rotate(right_Object_5_R, glm::radians(0.0f), glm::vec3(0.0, 1.0, 0.0));
	right_Object_5_R2 = glm::rotate(right_Object_5_R2, glm::radians(-90.0f), glm::vec3(1.0, 0.0, 0.0));
	right_Object_5_T = glm::translate(left_Object_5_T, glm::vec3(0.4f, 0.6f, -0.0f));
	RR = RR1 * RR2 * right_Object_5_T * Floor_21_T * right_Object_5_R2 * right_Object_5_R * right_Object_5_S;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));

	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, texture[4]);
	glUniform1i(glGetUniformLocation(shaderProgramID, "objectTexture"), 0);
	glUniform3f(objColorLocation, 1.0, 1.0, 1.0);
	glBindVertexArray(model10.vao);
	glDrawElements(GL_TRIANGLES, model10.indices.size(), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);
	glBindTexture(GL_TEXTURE_2D, 0);



	//------------------------------------------------------------ ��ֹ�
	//��ư
	for (int i = 0; i < 6; ++i) {
		glm::mat4 rectTransform = glm::mat4(1.0f);
		glm::mat4 rectTransform1 = glm::mat4(1.0f);
		glm::mat4 rectTransform2 = glm::mat4(1.0f);
		glm::mat4 rectTransform3 = glm::mat4(1.0f);
		glm::mat4 rectTransform4 = glm::mat4(1.0f);
		glm::mat4 rectTransform5 = glm::mat4(1.0f);
		rectTransform1 = glm::translate(rectTransform1, glm::vec3(rects[i].x, rects[i].y, rects[i].z));
		rectTransform2 = glm::scale(rectTransform2, glm::vec3(rects[i].sx, rects[i].sy, rects[i].sz));

		rectTransform = RR1 * RR2 * rectTransform1 * rectTransform2;

		// ��ȯ ����� ���̴��� ����
		glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(rectTransform));

		// ���� ���� (�� �簢���� �ٸ� ���� ����)
		if (rects[i].on) {
			glUniform3f(objColorLocation, 0.0f, 0.0f, 1.0f); // �Ķ��� (Ȱ��ȭ)
		}
		else {
			glUniform3f(objColorLocation, 1.0f, 0.65f, 0.0f); // �������� (��Ȱ��ȭ)
		}

		// VAO ���ε� �� �׸���


		rectTransform3 = glm::scale(rectTransform3, glm::vec3(2.0f, 2.0f, 2.0f));
		rectTransform4 = glm::translate(rectTransform4, glm::vec3(0.0f, 0.1f, -0.25f));
		rectTransform5 = glm::rotate(rectTransform5, glm::radians(-90.0f), glm::vec3(1.0, 0.0, 0.0));
		rectTransform = RR1 * RR2 * rectTransform4 * rectTransform1 * rectTransform5 * rectTransform3;
		glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(rectTransform));


		glBindVertexArray(model16.vao);
		glDrawElements(GL_TRIANGLES, model16.indices.size(), GL_UNSIGNED_INT, 0);
		glBindVertexArray(0);

		rectTransform = RR1 * RR2 * rectTransform1 * rectTransform2;
		glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(rectTransform));
		glUniform3f(objColorLocation, 1.0f, 1.0f, 0.0f);
		glBindVertexArray(floor_base.vao);
		glDrawArrays(GL_TRIANGLES, 0, 3); // �ﰢ�� 1
		glDrawArrays(GL_TRIANGLES, 1, 3); // �ﰢ�� 2
		glBindVertexArray(0);
	}
	if (puzzle_solve) {
		glutLeaveMainLoop();
	}


	//��
	for (int i = 0; i < 2; i++)
	{
		if (ball[i].ball_active)
		{
			glm::mat4 bigBall_T = glm::translate(glm::mat4(1.0f), glm::vec3(ff[23].x + 4.0f - ball_move[i], ff[23].y + 0.9f, ff[23].z)); // ��ġ ��ȯ (ff[23] ���� �ణ ����)
			glm::mat4 bigBall_S = glm::scale(glm::mat4(1.0f), glm::vec3(0.07f, 0.07f, 0.07f)); // �� ũ�� ����
			glm::mat4 bigBallTransform = bigBall_T * bigBall_S;

			glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(bigBallTransform));
			glUniform3f(objColorLocation, 0.5, 0.5, 0.5); // ���� ���� (������)

			// bigBall�� VAO�� ���ε��ϰ� ������
			glBindVertexArray(model7.vao);
			glDrawElements(GL_TRIANGLES, model7.indices.size(), GL_UNSIGNED_INT, 0);
			glBindVertexArray(0);
		}
	}

	//�� �浹�ڽ� �ʱ� ��ġ
	ballBox.position = glm::vec3(ff[23].x + 4.0f, ff[23].y + 0.65f, ff[23].z); // �ʱ� �� ��ġ�� ����
	ballBox.size = glm::vec3(ball[0].radius * 2.0f); // ���� ���� ũ��� �ڽ� ����


	//------------------------------------------------------------------------------------------------
	
	// ���ΰ�
	JuingGong_T = glm::translate(JuingGong_T, glm::vec3(boy.x, boy.y, boy.z));
	JuingGong_R = glm::rotate(JuingGong_R, glm::radians(-boy_yaw + 90.0f), glm::vec3(0.0, 1.0, 0.0));
	CS = glm::scale(CS, glm::vec3(0.0005, 0.0005, 0.0005));
	RR = RR1 * RR2 * JuingGong_T * JuingGong_R* CS;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));

	glUniform3f(objColorLocation, 0.0, 0.0, 0.0);
	glBindVertexArray(model1.vao);
	glDrawElements(GL_TRIANGLES, model1.indices.size(), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);
	glUniform3f(objColorLocation, 1.0, 1.0, 1.0);
	glBindVertexArray(model2.vao);
	glDrawElements(GL_TRIANGLES, model2.indices.size(), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);
	glUniform3f(objColorLocation, 1.0, 1.0, 1.0);
	glBindVertexArray(model3.vao);
	glDrawElements(GL_TRIANGLES, model3.indices.size(), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);
	glUniform3f(objColorLocation, 1.0, 0.0, 0.0);
	glBindVertexArray(model4.vao);
	glDrawElements(GL_TRIANGLES, model4.indices.size(), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);

	//---------------------------------------------------------------------------
	// ���� ����
	Tree_T = glm::translate(Tree_T, glm::vec3(10.0, -3.0, 0.0));
	Tree_S = glm::scale(Tree_S, glm::vec3(0.5, 0.5, 0.5));
	RR = RR1 * RR2 * Tree_T * Tree_S;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));

	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, texture[1]);
	glUniform1i(glGetUniformLocation(shaderProgramID, "objectTexture"), 0);
	glUniform3f(objColorLocation, 1.0, 1.0, 1.0);
	glBindVertexArray(model5.vao);
	glDrawElements(GL_TRIANGLES, model5.indices.size(), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);
	glBindTexture(GL_TEXTURE_2D, 0);

	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, texture[2]);
	glUniform1i(glGetUniformLocation(shaderProgramID, "objectTexture"), 0);
	glUniform3f(objColorLocation, 1.0, 1.0, 1.0);
	glBindVertexArray(model6.vao);
	glDrawElements(GL_TRIANGLES, model6.indices.size(), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);
	glBindTexture(GL_TEXTURE_2D, 0);

	//-----------------------------------------------------------------------------
	// ��ǳ��
	glm::mat4 propeller_T = glm::mat4(1.0f);
	glm::mat4 propeller_T2 = glm::mat4(1.0f);
	glm::mat4 propeller_T3 = glm::mat4(1.0f);
	glm::mat4 propeller_S = glm::mat4(1.0f);
	glm::mat4 propeller_R = glm::mat4(1.0f);
	glm::mat4 propeller_R2 = glm::mat4(1.0f);

	propeller_T = glm::translate(propeller_T, glm::vec3(20.0, 2.0, -5.5));
	propeller_S = glm::scale(propeller_S, glm::vec3(0.1, 0.1, 0.1));
	propeller_R = glm::rotate(propeller_R, glm::radians(propeller_r), glm::vec3(0.0, 0.0, 1.0));
	propeller_R2 = glm::rotate(propeller_R2, glm::radians(90.0f), glm::vec3(0.0, 1.0, 0.0));


	RR = RR1 * RR2 * propeller_T * propeller_R2 * propeller_R * propeller_S;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));

	glUniform3f(objColorLocation, 0.8, 0.8, 0.8);
	glBindVertexArray(model8.vao);
	glDrawElements(GL_TRIANGLES, model8.indices.size(), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);

	propeller_T2 = glm::translate(propeller_T2, glm::vec3(20.0, 2.0, -7.5));
	RR = RR1 * RR2 * propeller_T2 * propeller_R2 * propeller_R * propeller_S;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));

	glUniform3f(objColorLocation, 0.8, 0.8, 0.8);
	glBindVertexArray(model8.vao);
	glDrawElements(GL_TRIANGLES, model8.indices.size(), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);

	propeller_T3 = glm::translate(propeller_T3, glm::vec3(20.0, 2.0, -9.5));
	RR = RR1 * RR2 * propeller_T3 * propeller_R2 * propeller_R * propeller_S;
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(RR));

	glUniform3f(objColorLocation, 0.8, 0.8, 0.8);
	glBindVertexArray(model8.vao);
	glDrawElements(GL_TRIANGLES, model8.indices.size(), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);


	glutSwapBuffers();					// ȭ�鿡 ����ϱ�
}

GLvoid Reshape(int w, int h)		//--- �ݹ� �Լ�: �ٽ� �׸��� �ݹ� �Լ�
{
	glViewport(0, 0, w, h);

}

void InitBuffer_obj(Model& model) {
	glGenVertexArrays(1, &model.vao);
	glBindVertexArray(model.vao);

	// VBO ���� �� ������ ���ε�
	glGenBuffers(1, model.vbo);
	glBindBuffer(GL_ARRAY_BUFFER, model.vbo[0]);
	glBufferData(GL_ARRAY_BUFFER, model.vertices.size() * sizeof(Vertex), &model.vertices[0], GL_STATIC_DRAW);

	// ���� ��ġ �Ӽ�
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, position));
	glEnableVertexAttribArray(0);

	// ���� ��� �Ӽ�
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, normal));
	glEnableVertexAttribArray(1);

	// �ؼ� ��ǥ �Ӽ�
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, texCoord));
	glEnableVertexAttribArray(2);

	// �ε��� ������ ����
	model.indices.clear();
	for (const auto& face : model.faces) {
		model.indices.push_back(face.v1);
		model.indices.push_back(face.v2);
		model.indices.push_back(face.v3);
	}

	// EBO ����
	glGenBuffers(1, &model.ebo);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, model.ebo);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, model.indices.size() * sizeof(unsigned int), &model.indices[0], GL_STATIC_DRAW);

	glBindVertexArray(0);
}


void InitBuffer()
{
	glGenVertexArrays(1, &Line_xy.vao); // vao �� �����ϰ� �Ҵ��ϱ�
	glBindVertexArray(Line_xy.vao); // vao�� ���ε��ϱ�
	glGenBuffers(2, Line_xy.vbo); // 2���� vbo�� �����ϰ� �Ҵ��ϱ�

	glBindBuffer(GL_ARRAY_BUFFER, Line_xy.vbo[0]);
	glBufferData(GL_ARRAY_BUFFER, 12 * sizeof(GLfloat), Line_xy.xyz, GL_STATIC_DRAW);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(0);

	glBindBuffer(GL_ARRAY_BUFFER, Line_xy.vbo[1]);
	glBufferData(GL_ARRAY_BUFFER, 12 * sizeof(GLfloat), Line_xy.nomal, GL_STATIC_DRAW);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(1);

	glBindVertexArray(0);

	glGenVertexArrays(1, &Line_z.vao); // vao �� �����ϰ� �Ҵ��ϱ�
	glBindVertexArray(Line_z.vao); // vao�� ���ε��ϱ�
	glGenBuffers(2, Line_z.vbo); // 2���� vbo�� �����ϰ� �Ҵ��ϱ�

	glBindBuffer(GL_ARRAY_BUFFER, Line_z.vbo[0]);
	glBufferData(GL_ARRAY_BUFFER, 12 * sizeof(GLfloat), Line_z.xyz, GL_STATIC_DRAW);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(0);

	glBindBuffer(GL_ARRAY_BUFFER, Line_z.vbo[1]);
	glBufferData(GL_ARRAY_BUFFER, 12 * sizeof(GLfloat), Line_z.nomal, GL_STATIC_DRAW);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(1);

	glBindVertexArray(0);
	//--------------------------------------------------------------------
	glGenVertexArrays(1, &floor_base.vao); // vao �� �����ϰ� �Ҵ��ϱ�
	glBindVertexArray(floor_base.vao); // vao�� ���ε��ϱ�
	glGenBuffers(2, floor_base.vbo); // 2���� vbo�� �����ϰ� �Ҵ��ϱ�

	glBindBuffer(GL_ARRAY_BUFFER, floor_base.vbo[0]);
	glBufferData(GL_ARRAY_BUFFER, 12 * sizeof(GLfloat), floor_base.xyz, GL_STATIC_DRAW);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(0);

	glBindBuffer(GL_ARRAY_BUFFER, floor_base.vbo[1]);
	glBufferData(GL_ARRAY_BUFFER, 12 * sizeof(GLfloat), floor_base.nomal, GL_STATIC_DRAW);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(1);

	glGenBuffers(1, &floor_base.vbo[2]);
	glBindBuffer(GL_ARRAY_BUFFER, floor_base.vbo[2]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(floor_base.texCoord), floor_base.texCoord, GL_STATIC_DRAW);

	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 0, 0); // location=2
	glEnableVertexAttribArray(2);

	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(0);
	//----------------------------------------------------------------------
	glGenVertexArrays(1, &wall_base.vao); // vao �� �����ϰ� �Ҵ��ϱ�
	glBindVertexArray(wall_base.vao); // vao�� ���ε��ϱ�
	glGenBuffers(2, wall_base.vbo); // 2���� vbo�� �����ϰ� �Ҵ��ϱ�

	glBindBuffer(GL_ARRAY_BUFFER, wall_base.vbo[0]);
	glBufferData(GL_ARRAY_BUFFER, 12 * sizeof(GLfloat), wall_base.xyz, GL_STATIC_DRAW);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(0);

	glBindBuffer(GL_ARRAY_BUFFER, wall_base.vbo[1]);
	glBufferData(GL_ARRAY_BUFFER, 12 * sizeof(GLfloat), wall_base.nomal, GL_STATIC_DRAW);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(1);

	glGenBuffers(1, &wall_base.vbo[2]);
	glBindBuffer(GL_ARRAY_BUFFER, wall_base.vbo[2]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(wall_base.texCoord), wall_base.texCoord, GL_STATIC_DRAW);

	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 0, 0); // location=2
	glEnableVertexAttribArray(2);

	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(0);
}

void InitTexture() {
	// �ؽ�ó 3�� ����
	glGenTextures(10, texture);

	glBindTexture(GL_TEXTURE_2D, texture[0]);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	unsigned char* data = stbi_load("sky.jpg", &widthImage, &heghtImage, &numberOfChannel, 0);
	if (!data) {
		std::cerr << "Failed to load texture" << std::endl;
		return;
	}

	int format = (numberOfChannel == 4) ? GL_RGBA : GL_RGB;
	glTexImage2D(GL_TEXTURE_2D, 0, format, widthImage, heghtImage, 0, format, GL_UNSIGNED_BYTE, data);

	stbi_image_free(data);

	// ----------
	glBindTexture(GL_TEXTURE_2D, texture[1]);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	data = stbi_load("tree1.jpg", &widthImage, &heghtImage, &numberOfChannel, 0);
	if (!data) {
		std::cerr << "Failed to load texture" << std::endl;
		return;
	}

	format = (numberOfChannel == 4) ? GL_RGBA : GL_RGB;
	glTexImage2D(GL_TEXTURE_2D, 0, format, widthImage, heghtImage, 0, format, GL_UNSIGNED_BYTE, data);

	stbi_image_free(data);

	//---------------------------------------------------------
	glBindTexture(GL_TEXTURE_2D, texture[2]);

	// �ؽ�ó �Ű����� ����
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	data = stbi_load("tree2.jpg", &widthImage, &heghtImage, &numberOfChannel, 0);
	if (!data) {
		std::cerr << "Failed to load texture" << std::endl;
		return;
	}

	format = (numberOfChannel == 4) ? GL_RGBA : GL_RGB;
	glTexImage2D(GL_TEXTURE_2D, 0, format, widthImage, heghtImage, 0, format, GL_UNSIGNED_BYTE, data);

	stbi_image_free(data);
	// --------------------------------------------
	glBindTexture(GL_TEXTURE_2D, texture[3]);

	// �ؽ�ó �Ű����� ����
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	data = stbi_load("container.jpg", &widthImage, &heghtImage, &numberOfChannel, 0);
	if (!data) {
		std::cerr << "Failed to load texture" << std::endl;
		return;
	}

	format = (numberOfChannel == 4) ? GL_RGBA : GL_RGB;
	glTexImage2D(GL_TEXTURE_2D, 0, format, widthImage, heghtImage, 0, format, GL_UNSIGNED_BYTE, data);

	stbi_image_free(data);
	//-------------------------------------------------
	glBindTexture(GL_TEXTURE_2D, texture[4]);

	// �ؽ�ó �Ű����� ����
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	data = stbi_load("keyboard.png", &widthImage, &heghtImage, &numberOfChannel, 0);
	if (!data) {
		std::cerr << "Failed to load texture" << std::endl;
		return;
	}

	format = (numberOfChannel == 4) ? GL_RGBA : GL_RGB;
	glTexImage2D(GL_TEXTURE_2D, 0, format, widthImage, heghtImage, 0, format, GL_UNSIGNED_BYTE, data);

	stbi_image_free(data);
	//-------------------------------------------------
	glBindTexture(GL_TEXTURE_2D, texture[5]);

	// �ؽ�ó �Ű����� ����
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	data = stbi_load("audio.jpg", &widthImage, &heghtImage, &numberOfChannel, 0);
	if (!data) {
		std::cerr << "Failed to load texture" << std::endl;
		return;
	}

	format = (numberOfChannel == 4) ? GL_RGBA : GL_RGB;
	glTexImage2D(GL_TEXTURE_2D, 0, format, widthImage, heghtImage, 0, format, GL_UNSIGNED_BYTE, data);

	stbi_image_free(data);
	glUseProgram(shaderProgramID);
	int tLocation = glGetUniformLocation(shaderProgramID, "outTexture");
	glUniform1i(tLocation, 0); // �ؽ�ó ���� 0�� �⺻���� ����
}


void TimerFunction(int value)
{
	// �����緯 ȸ��
	propeller_r += 4.0;

	float dir_x = 0.0f, dir_z = 0.0f;

	// Ű ���¿� ���� ���� ���
	if (pressedKeys['w']) { // ������ �̵�
		float temp_x, temp_z;
		UpdateDirection(temp_x, temp_z, 180.0f);
		dir_x += temp_x;
		dir_z += temp_z;
	}
	if (pressedKeys['s']) { // �ڷ� �̵�
		float temp_x, temp_z;
		UpdateDirection(temp_x, temp_z, 0.0f);
		dir_x += temp_x;
		dir_z += temp_z;
	}
	if (pressedKeys['a']) { // ���� �̵�
		float temp_x, temp_z;
		UpdateDirection(temp_x, temp_z, 90.0f);
		dir_x += temp_x;
		dir_z += temp_z;
	}
	if (pressedKeys['d']) { // ������ �̵�
		float temp_x, temp_z;
		UpdateDirection(temp_x, temp_z, -90.0f);
		dir_x += temp_x;
		dir_z += temp_z;
	}

	// ����ȭ�� �������� �̵�
	float magnitude = sqrt(dir_x * dir_x + dir_z * dir_z);
	if (magnitude > 0.0f) {
		boy.x += (dir_x / magnitude) * 0.01f; // ������ �ӵ� ����
		boy.z += (dir_z / magnitude) * 0.01f;
	}

	// ���� �� �߷� ó��
	if (boy.jump) {
		boy.y += boy.verticalSpeed;      // ���� �ӵ��� ���� ���
		boy.verticalSpeed -= boy.gravity; // �߷¿� ���� �ӵ� ����

		// �ְ��� ���� �ϰ�
		if (boy.verticalSpeed <= 0) {
			boy.jump = false; // ���� ����, ���� ���Ϸ� ��ȯ
		}
	}
	else if (!boy.ground) { // ���� ���� ��
		boy.y -= boy.gravity * 10; // �߷¿� ���� �ϰ�
		// �ٴ� �浹 Ȯ��
		/*
		if (boy.y <= 0.1f) {  // �ٴڿ� ����
		   boy.y = 0.1f;     // �ٴ� ���̷� ����
		   boy.ground = true;
		}
		*/
	}

	// ���ΰ� �ٴ� �浹 ó��
	bool isOnGround = false;

	// ���ΰ� �ٴ� �浹 ó�� (ff)
	for (int i = 0; i < 30; ++i) {
		float halfWidth = ff[i].sx * 0.3f;
		float halfDepth = ff[i].sz * 0.3f;

		if ((boy.x >= ff[i].x - halfWidth) && (boy.x <= ff[i].x + halfWidth) &&
			(boy.z >= ff[i].z - halfDepth) && (boy.z <= ff[i].z + halfDepth)) {
			float groundOffset = 0.05f;
			float groundThickness = 0.005f;

			if (boy.y <= ff[i].y + groundOffset && boy.y >= ff[i].y - groundThickness) {
				isOnGround = true;  // ���̰� ff ���� ����
			}
		}
	}

	// �����̴� �ٴ� (ff2)
	for (int i = 0; i < 10; ++i) {
		// �����̴� �ٴ� ����
		if (ff2[i].move) {
			if (ff2[i].move_direction == 0) {
				if (ff2[i].z <= ff2[i].goal1) ff2[i].plus = false;
				if (ff2[i].z >= ff2[i].goal2) ff2[i].plus = true;

				ff2[i].z += ff2[i].plus ? -0.01f : 0.01f;
			}
			else if (ff2[i].move_direction == 1) {
				if (ff2[i].x <= ff2[i].goal1) ff2[i].plus = false;
				if (ff2[i].x >= ff2[i].goal2) ff2[i].plus = true;

				ff2[i].x += ff2[i].plus ? -0.01f : 0.01f;
			}
			else if (ff2[i].move_direction == 2) {
				if (ff2[i].y <= ff2[i].goal1) ff2[i].plus = false;
				if (ff2[i].y >= ff2[i].goal2) ff2[i].plus = true;

				ff2[i].y += ff2[i].plus ? -0.007f : 0.007f;
			}
		}

		// �����̴� �ٴ� �浹 ����
		float halfWidth = ff2[i].sx * 0.3f;
		float halfDepth = ff2[i].sz * 0.3f;

		if ((boy.x >= ff2[i].x - halfWidth) && (boy.x <= ff2[i].x + halfWidth) &&
			(boy.z >= ff2[i].z - halfDepth) && (boy.z <= ff2[i].z + halfDepth)) {
			float groundOffset = 0.05f;
			float groundThickness = 0.005f;

			if (boy.y <= ff2[i].y + groundOffset && boy.y >= ff2[i].y - groundThickness) {
				isOnGround = true;  // ���̰� ff2 ���� ����

				if (i == 4) {
					boy.x -= 0.009f;
				}
				else {
					// �����̴� �ٴ� ���� �̵�
					if (ff2[i].move_direction == 0) {
						boy.z += ff2[i].plus ? -0.01f : 0.01f;
					}
					else if (ff2[i].move_direction == 1) {
						boy.x += ff2[i].plus ? -0.01f : 0.01f;
					}
					else if (ff2[i].move_direction == 2) {
						boy.y += ff2[i].plus ? -0.007f : 0.007f;
					}
				}
			}
		}
	}

	// ��� �ٴ��� �˻��� �� ���� ������Ʈ
	boy.ground = isOnGround;

	//�������� ����
	for (int i = 17; i <= 20; ++i) {
		if (!ff[i].fallingTimerActive && !ff[i].falling) {
			float halfWidth = ff[i].sx * 0.3f;
			float halfDepth = ff[i].sz * 0.3f;

			// ���ΰ��� �ٴ� ���� �ִ��� Ȯ��
			if ((boy.x >= ff[i].x - halfWidth) && (boy.x <= ff[i].x + halfWidth) &&
				(boy.z >= ff[i].z - halfDepth) && (boy.z <= ff[i].z + halfDepth) &&
				boy.y <= ff[i].y + 0.05f && boy.y >= ff[i].y - 0.005f) {
				ff[i].fallingTimerActive = true; // Ÿ�̸� Ȱ��ȭ
				ff[i].fallingStartTime = glutGet(GLUT_ELAPSED_TIME) / 1000.0f; // �� ���� ���
			}
		}
		else if (ff[i].fallingTimerActive && !ff[i].falling) {
			// Ÿ�̸Ӱ� 0.5�� ����ߴ��� Ȯ��
			float currentTime = glutGet(GLUT_ELAPSED_TIME) / 1000.0f;
			if (currentTime - ff[i].fallingStartTime >= 0.5f) {
				ff[i].falling = true; // 0.5�� �ڿ� �������� ����
				ff[i].fallingTimerActive = false; // Ÿ�̸� ��Ȱ��ȭ
			}
		}

		if (ff[i].falling) {
			// �������� �ӵ� ó��
			ff[i].y -= ff[i].fallSpeed; // �������� �ӵ� ����
			ff[i].fallSpeed += 0.001f; // �߷� ���ӵ� ����

			// Ư�� ���� ���Ϸ� ���������� ����
			if (ff[i].y < -10.0f) {
				ff[i].fallSpeed = 0.0f; // �ӵ� �ʱ�ȭ
				ff[i].falling = false; // �������� ���� ����
				ff[i].y = 1.2f; // ���� y������ ����
				ff[i].fallingStartTime = 0.0f; // Ÿ�̸� �ʱ�ȭ
			}
		}
	}

	CollisionBox playerBox = { glm::vec3(boy.x, boy.y, boy.z), glm::vec3(0.1f, 0.2f, 0.1f) };


	for (int i = 0; i < 2; i++) {
		if (ball[i].ball_active) {
			CollisionBox ballBox = { glm::vec3(ff[23].x + 4.0f - ball_move[i], ff[23].y + 0.9f, ff[23].z), glm::vec3(1.8f, 1.8f, 1.8f) };

			ball_move[i] += 0.05f;
			ball[i].position.x = ff[23].x + 4.0f - ball_move[i];

			if (checkCollision(playerBox, ballBox)) {
				glm::vec3 randomDirection = generateRandomDirection();
				float force = 0.05f;
				boy.velocity = randomDirection * force;
				boy.velocity.y = 0.03f;
				boy.isFlying = true;
			}
		}
	}

	//�� �ֱ������� ��ȯ
	static float timeSinceLastBall = 0.0f;  // �� ����� ���� ����
	float currentTime = glutGet(GLUT_ELAPSED_TIME) / 1000.0f; // �� ���� �ð�
	if (currentTime - timeSinceLastBall > 5.0f) { // 3�� ����
		for (int i = 0; i < 2; ++i) {
			if (!ball[i].ball_active) { // ��Ȱ�� ������ �� Ȱ��ȭ
				ball[i].ball_active = true;
				ball[i].position = glm::vec3(ff[23].x + 4.0f, ff[23].y + 0.65f, ff[23].z);
				ball[i].velocity = glm::vec3(-0.05f, 0.0f, 0.0f); // �� �ӵ� ����
				timeSinceLastBall = currentTime; // �� Ȱ��ȭ �ð� ���
				break; // �� ���� �ϳ��� ���� Ȱ��ȭ
			}
		}
	}

	// �� �̵� �� ��Ȱ��ȭ
	for (int i = 0; i < 2; ++i) {
		if (ball[i].ball_active) {
			ball[i].position += ball[i].velocity; // �ӵ��� ���� �� �̵�
			ball_move[i] += 0.05f; // ���� ��ġ ����

			// ���� Ư�� ��ġ�� ������ ��Ȱ��ȭ
			if (ball[i].position.x < ff[23].x - 4.0f) {
				ball[i].position = glm::vec3(ff[23].x + 4.0f - ball_move[i], ff[23].y + 0.65f, ff[23].z);
				ball[i].velocity = glm::vec3(0.0f);
				ball[i].radius = 0.1f;
				ball[i].ball_active = false;
				ball_move[i] = 0.0f;
			}

			// �浹 ó�� (�÷��̾�� ��)
			CollisionBox ballBox = { ball[i].position, glm::vec3(ball[i].radius * 2.0f) };
			CollisionBox playerBox = { glm::vec3(boy.x, boy.y, boy.z), glm::vec3(0.1f, 0.2f, 0.1f) };

			if (checkCollision(playerBox, ballBox)) {
				glm::vec3 randomDirection = generateRandomDirection();
				float force = 0.05f;
				boy.velocity = randomDirection * force;
				boy.velocity.y = 0.03f;
				boy.isFlying = true;
			}
		}
	}

	glm::vec3 randomDirection = generateRandomDirection();

	//�浹ó��
	if (checkCollision(playerBox, ballBox)) {
		glm::vec3 randomDirection = generateRandomDirection();
		float force = 0.05f; // ���ư��� �ʱ� �ӵ� ũ��
		boy.velocity = randomDirection * force;
		boy.velocity.y = 0.03f; // ���� ���� �ʱ� �ӵ�
		boy.isFlying = true; // ���ư��� ���·� ����
	}

	if (boy.isFlying) {
		boy.x += boy.velocity.x;
		boy.y += boy.velocity.y;
		boy.z += boy.velocity.z;

		// �ӵ��� ���ӵ�(�߷�) ����
		boy.velocity += boy.acceleration;

		// �ٴڿ� �����ϸ� ����
		if (boy.y <= 0.1f) {
			boy.y = 0.1f; // �ٴ� ���̷� ����
			boy.velocity = glm::vec3(0.0f); // �ӵ� �ʱ�ȭ
			boy.isFlying = false; // ���ư��� ���� ����
		}
	}

	for (int i = 0; i < 6; i++)
	{
		if (!rects[i].on)
		{
			puzzle_solve = false;
		}
	}


	// ���ΰ� �������� ����
	if (boy.y < -2.0f) {
		boy.y = 0.9f;
		boy.x = 0.0f;
		boy.z = 0.0f;
		boy.ground = true;
		boy.jump = false;
		boy.verticalSpeed = 0.0f;
	}

	glutTimerFunc(5, TimerFunction, 0);
	glutPostRedisplay();
}

//���� �浹�ϴ� ���ΰ� ���ư��� ����
glm::vec3 generateRandomDirection() {
	float angle = static_cast<float>(rand() % 360);
	float x = cos(glm::radians(angle));
	float z = sin(glm::radians(angle));
	return glm::normalize(glm::vec3(x, 0.0f, z));
}

//�浹ó��
bool checkCollision(const CollisionBox& box1, const CollisionBox& box2) {
	return (abs(box1.position.x - box2.position.x) <= (box1.size.x + box2.size.x) / 2.0f &&
		abs(box1.position.y - box2.position.y) <= (box1.size.y + box2.size.y) / 2.0f &&
		abs(box1.position.z - box2.position.z) <= (box1.size.z + box2.size.z) / 2.0f);
}

void UpdateDirection(float& dir_x, float& dir_z, float angleOffset) {
	float radian = glm::radians(yaw + angleOffset);
	dir_x = cos(radian);
	dir_z = sin(radian);
}

void CheckPuzzleCondition() {
	bool allButtonsActivated = true;

	// ��� ��ư�� ���� Ȯ��
	for (int i = 0; i < 6; ++i) {
		if (!rects[i].on) {
			allButtonsActivated = false;
			break;
		}
	}

	if (allButtonsActivated && !puzzle_solve) {
		puzzle_solve = true;
		std::cout << "������ Ǯ�Ƚ��ϴ�!" << std::endl;

	}
}

void Keyboard(unsigned char key, int x, int y) {
	pressedKeys[key] = true; // Ű ���� ���
	switch (key) {
	case 'q':  // ���α׷� ����
		glutLeaveMainLoop();
		break;
	case 'r':
		boy.y = 0.6f;
		boy.x = 0.0f;
		boy.z = 0.0f;
		boy.ground = true;
		boy.jump = false;
		boy.verticalSpeed = 0.0f;
	case ' ': // ����
		if (boy.ground) { // �ٴڿ� ���� ���� ���� ����
			boy.jump = true;
			boy.ground = false;
			boy.verticalSpeed = boy.jumpPower; // �ʱ� ���� �ӵ� ����
		}
		break;
	case 'e': // ��ư Ȱ��ȭ
		for (int i = 0; i < 6; ++i) {
			float halfWidth = rects[i].sx * 0.5f;
			float halfDepth = rects[i].sz * 0.5f;

			// ���ΰ��� i��° ��ư ���� �ִ��� Ȯ��
			if ((boy.x >= rects[i].x - halfWidth && boy.x <= rects[i].x + halfWidth) &&
				(boy.z >= rects[i].z - halfDepth && boy.z <= rects[i].z + halfDepth) &&
				boy.y <= rects[i].y + 0.05f && boy.y >= rects[i].y - 0.005f) {

				// ���� ��� ���� �ִ� ��� ��ư�� ���¸� ����
				for (int j = 0; j < 6; ++j) {
					if (rects[j].x == rects[i].x || rects[j].z == rects[i].z) {
						rects[j].on = !rects[j].on; // ���� ����
					}
				}
			}
		}

		CheckPuzzleCondition();

		break;
	}



}

void Keyboard_up(unsigned char key, int x, int y) {
	pressedKeys[key] = false; // Ű ���� ����
}


void SpecialKeyboard(int key, int x, int y)
{
	
	glutPostRedisplay();
}

void Motion(int x, int y)
{
	int centerX = windowWidth / 2;
	int centerY = windowHeight / 2;

	if (firstMouse) {
		// ���콺 �ʱ�ȭ
		firstMouse = false;
		glutWarpPointer(centerX, centerY); // ȭ�� �߾����� �̵�
		return;
	}

	float xOffset = x - centerX;
	float yOffset = centerY - y;

	xOffset *= sensitivity;
	yOffset *= sensitivity/6.0f;

	yaw += xOffset;
	pitch -= yOffset;

	if (pitch > 89.0f)
		pitch = 89.0f;
	if (pitch < -89.0f)
		pitch = -89.0f;

	cameraDirection.x = boy.x;
	cameraDirection.y = boy.y;
	cameraDirection.z = boy.z;


	// ī�޶� ��ġ ���
	cameraPos.x = boy.x + radius * cos(glm::radians(yaw)) * cos(glm::radians(pitch));
	cameraPos.y = boy.y + radius * sin(glm::radians(pitch));
	cameraPos.z = boy.z + radius * sin(glm::radians(yaw)) * cos(glm::radians(pitch));
	// �� ��� ������Ʈ
	view = glm::lookAt(cameraPos, cameraDirection, cameraUp);

	boy_yaw = yaw;

	glutWarpPointer(centerX, centerY);

	glutPostRedisplay();
}
